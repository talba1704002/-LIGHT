Talha Light - full-screen WebView app for the ESP32 light controller

1. Create a new GitHub repo and upload EVERYTHING from this zip (keep the folder structure,
   including the hidden ".github" folder).
2. Go to the repo > Actions > "Build Android APK" (runs on every push, or press "Run workflow").
3. When it finishes, open the run and download the artifact "TalhaLight-apk" -> TalhaLight.apk
4. Install on the phone (allow "install unknown apps").

The app bundles its own interface (Home + Schedule) in app/src/main/assets/index.html and talks to the
controller (firmware v14.x, password login) through a Java bridge:
  - every request is sent to http://esplight.local/ (no IP addresses are used or typed). If Android cannot
    resolve the .local name itself, the name is resolved through an mDNS service search and the request still
    carries "Host: esplight.local".
  - keeps the login cookie and re-logs in with the saved password after a controller reboot.
  - always uses the Wi-Fi network, even if it has no internet.
Top bar: CPU temperature, RTC status (tap = set clock to phone time), settings (edit mode: rename / change
GPIO / delete switches), plus (new switch, default name = its GPIO pin). Switches are hexagons in a honeycomb.
