// ============================================================
//  ESP32 + DS3231 RTC MULTI-SWITCH CONTROLLER  +  SYNC WEB UI  (v14.11)
//
//  Wi-Fi AP : SSID "LIGHT"  /  NO password (open network) by default
//  Web UI   : http://192.168.1.1   (via AP)
//             http://esplight.local/  (via your router, after setup)
//
//  v14.11 (SPEED / STABILITY, no feature change):
//   * Wi-Fi modem power-save OFF (WiFi.setSleep(false)): removes the 100-300 ms
//     wake-up delay on every request and many "connection drop" moments.
//   * CPU never below 160 MHz (was 80 MHz): Wi-Fi + TCP + JSON are ~2x faster.
//   * AP default Max clients 1 -> 4: a phone that reconnects/roams is no longer
//     refused while the old (stale) association is still being timed out.
//   * Main loop delay 5 ms -> 1 ms.
//   * Router reconnect: first retry ~1 s after a drop, then every 10 s. While a
//     phone is on the AP it stays 300 s (a router scan hops channels and can
//     freeze/kick AP clients). Connect timeout 20 s -> 15 s.
//  v14.9: temp ON again; RTC pads released (rtc_gpio_deinit) + pull mode FLOATING on open-drain release.
//  v14.8: CPU temperature (temperatureRead) off by default: may disturb RTC-pad GPIOs.
//  v14.7: open-drain now = real float (INPUT) / sink (OUTPUT LOW) on every pin.
//
//  v14.6 (LOGIN):
//   * Web UI is protected by ONE password (no user name).
//   * First start (no password stored): page asks to create the password and
//     to type it again to confirm. Afterwards the page asks for the password.
//   * Settings > Advanced options: change password (old + new + confirm) and Log out.
//   * Eye button on every password box to show / hide what you type.
//   * Password is stored only as a salted SHA-256 hash in NVS. SYSTEM RESET
//     (web, button hold, FACTORYRESET) erases it too -> back to first-start state.
//   * 5 wrong passwords = 30 s lock. All /api/* calls need a valid login cookie.
//   * Login is kept in RAM only: a reboot logs everyone out.
//
//  v14.5 (cleanup: less work per UI action):
//   * RTC read once per second; schedules re-evaluated only when the minute
//     changes (was every 500 ms for every switch).
//   * Toggle / schedule save / switch save use the cached RTC time (no extra
//     I2C reads, no re-evaluation of every switch).
//   * FIX: saving a switch (even a rename) no longer re-inits the pin and
//     turns the load OFF. Pin is re-initialised only if pin/level/mode changed.
//   * FIX: deleting a switch re-saves schedules/overrides of the switches that
//     moved up (NVS keys are index based; they were mismatched after reboot).
//   * FIX: updateRTC() no longer runs while the RTC is marked failed.
//   * /api/status sends only changing data (no names/pins every 5 s).
//   * Unchanged saves do nothing and no longer force every phone to rebuild.
//     Reset-to-defaults no longer restarts the AP if already default.
//   * Removed 60 s serial status dump and dead code.
//   * Web UI: cards rebuilt only when needed, schedule editor / advanced form
//     built only when their tab opens, no double reload after a save.
//
//  v14.4:
//   * FIX: broken card layout (card class "off" clashed with the .off pill
//     style). Card state class is now "st-off".
//   * FIX: "Reset to defaults" / "Forget router" buttons now really send POST.
//   * NEW: SYSTEM RESET (Settings > Advanced options). Erases the WHOLE NVS
//     (switches, names, pins, schedules, overrides, AP state, router, advanced
//     settings) and restarts with factory defaults.
//   * CHANGED: button long press (hold) = SYSTEM RESET (same full erase).
//     Serial command FACTORYRESET does the same.
//
//  v14.3 (web UI only, firmware logic unchanged):
//   * New switch card design: green card when ON, red card when OFF,
//     blue header with Name / Schedule / Status / GPIO pills,
//     black toggle track, Auto button (green = auto, red = manual).
//
//  v14.2 (web UI only, firmware logic unchanged):
//   * Home cards are built once and updated in place (no more popup closing).
//   * Clock shows date + HH:MM (no seconds). Status poll every 5 s, silent.
//   * FORCE ON / FORCE OFF replaced by one toggle switch (AUTO button kept).
//
//  v14: up to 12 independent switches (relay outputs).
//   * Every switch has its own name, GPIO pin, schedules (10 each),
//     manual override, Active HIGH/LOW and Open-drain ON/OFF setting.
//   * Add / rename / re-pin / delete switches from the Home tab.
//
//  Usable output GPIOs (see ALLOWED_PINS below):
//    18 4 13 14 16 17 23 25 26 27 32 33   = 12 pins
//    Not used on purpose: 21/22 (I2C RTC), 19 (button), 1/3 (USB serial),
//    6-11 (flash), 34-39 (input only), 0/2/5/12/15 (boot strapping pins).
//
//  Button (GPIO 19, to GND, internal pull-up):
//    short press  = nothing (relays are controlled from the web UI)
//    double click = Wi-Fi AP ON <-> OFF   (state is SAVED in NVS)
//    long press   = SYSTEM RESET: erase ALL saved data (NVS) + restart (hold 2 s)
//  Required libraries: RTClib (Adafruit). WebServer/WiFi/ESPmDNS built in.
// ============================================================

#include <Wire.h>
#include "RTClib.h"
#include <Preferences.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <nvs_flash.h>
#include <mbedtls/sha256.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>

// ---------------- Hardware ----------------
const uint8_t DEFAULT_RELAY_PIN = 18;    // first switch (legacy pin)
const uint8_t BUTTON_PIN = 19;           // to GND, internal pull-up
const uint8_t SDA_PIN    = 21;
const uint8_t SCL_PIN    = 22;
const uint8_t RTC_I2C_ADDRESS = 0x68;

// GPIOs that may drive a switch. Order = order they are offered to new switches.
const uint8_t ALLOWED_PINS[] = { 18, 4, 13, 14, 16, 17, 23, 25, 26, 27, 32, 33 };
const uint8_t MAX_CH = sizeof(ALLOWED_PINS);   // 12

#ifdef LED_BUILTIN
const uint8_t STATUS_LED_PIN = LED_BUILTIN;
#else
const uint8_t STATUS_LED_PIN = 2;
#endif

// ---------------- Wi-Fi Access Point ----------------
const char *AP_SSID     = "LIGHT";
const char *AP_PASSWORD = "";          // open network by default

const IPAddress AP_IP     (192, 168, 1, 1);
const IPAddress AP_GATEWAY(192, 168, 1, 1);
const IPAddress AP_SUBNET (255, 255, 255, 0);

const bool AP_DEFAULT_ON = true;

// ---------------- Default schedule (used if NVS is empty) ----------------
const uint8_t DEFAULT_ON_HOUR    = 6;
const uint8_t DEFAULT_ON_MINUTE  = 0;
const uint8_t DEFAULT_OFF_HOUR   = 0;
const uint8_t DEFAULT_OFF_MINUTE = 0;

const uint16_t MIN_VALID_YEAR = 2024;
const uint16_t MAX_VALID_YEAR = 2099;

const uint8_t MAX_SCHEDULES = 10;      // per switch

// ---------------- Timing ----------------
const unsigned long DEBOUNCE_DELAY        = 40;
unsigned long LONG_PRESS_THRESHOLD  = 2000;
unsigned long DOUBLE_CLICK_WINDOW   = 300;
// temperatureRead() uses the ESP32 internal SAR/RTC block. GPIOs that are
// RTC pads (4, 13, 14, 25, 26, 27, 32, 33) can be disturbed by it, so it is
// ON again (v14.9): turning it off did not change the relay behaviour.
#define ENABLE_CPU_TEMP 1

const unsigned long RTC_READ_INTERVAL     = 1000;
const unsigned long RTC_RECOVERY_INTERVAL = 5000;
const unsigned long SERIAL_INPUT_TIMEOUT  = 2000;
const uint32_t      LOOP_DELAY_MS         = 1;
const uint16_t      MIN_CPU_MHZ           = 160;   // Wi-Fi/TCP need speed; 80 MHz made every reply slow

const uint8_t SERIAL_MAX_CHARS_PER_CYCLE = 64;

// ---------------- Override ----------------
enum OverrideMode : uint8_t { AUTO_MODE = 0, FORCE_ON = 1, FORCE_OFF = 2 };

// ---------------- Switch channels ----------------
struct ScheduleSlot
{
  uint8_t onH;
  uint8_t onM;
  uint8_t offH;
  uint8_t offM;
  uint8_t enabled;   // 1 = used, 0 = ignored
};

struct Channel
{
  // saved configuration
  uint8_t pin;
  uint8_t activeHigh;   // 1 = relay ON when pin HIGH, 0 = ON when pin LOW
  uint8_t openDrain;    // 1 = OUTPUT_OPEN_DRAIN, 0 = normal push-pull OUTPUT
  char    name[17];
  ScheduleSlot sch[MAX_SCHEDULES];
  uint8_t schCount;
  // runtime state
  OverrideMode ovr;
  bool    relay;        // logical state (true = load ON)
  bool    schedOn;      // schedule says ON now
  char    period[20];
};

Channel  chs[MAX_CH];
uint8_t  chCount = 1;
uint32_t cfgVersion = 1;                 // bumped on any config change (web UI reloads)

// ---------------- Objects / state ----------------
RTC_DS3231  rtc;
Preferences preferences;
WebServer   server(80);

bool rtcAvailable        = false;
bool rtcFailureLogged    = false;

DateTime currentTime(2000, 1, 1, 0, 0, 0);

// Button
bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;
bool buttonIsPressed   = false;
bool longPressHandled  = false;
unsigned long lastDebounceTime     = 0;
unsigned long buttonPressStartTime = 0;

uint8_t clickCount         = 0;
unsigned long pendingClickTime = 0;
bool wifiToggleRequested   = false;
bool factoryResetRequested = false;
bool apEnabled             = false;

// Timers
unsigned long lastRTCRead            = 0;
unsigned long lastRTCRecoveryAttempt = 0;
uint32_t lastEvalMinute = 0xFFFFFFFF;   // minute key of last schedule evaluation

// Serial parser
char    serialBuffer[32];
uint8_t serialIndex        = 0;
bool    serialOverflow     = false;
unsigned long lastSerialCharacterTime = 0;

// ============================================================
//  ADVANCED SETTINGS (saved in NVS as one blob, key "adv")
// ============================================================

struct AdvSettings
{
  uint8_t  magic;
  uint8_t  txIdx;
  uint8_t  channel;      // 1..13
  uint8_t  proto;        // 0 = b, 1 = b/g, 2 = b/g/n
  uint8_t  maxClients;   // 1..4
  uint8_t  autoOff;      // 1 = AP auto-off after 2 min without a phone
  uint16_t cpuMhz;       // 80 / 160 / 240
  uint16_t dblMs;        // 200..600
  uint16_t longMs;       // 1000..5000
  char     ssid[33];
  char     pass[64];     // empty = open network, otherwise 8..63 chars
};

const uint8_t ADV_MAGIC = 0xA5;

// Order must NOT change: saved settings store an index into this array.
const wifi_power_t TX_LEVELS[] = {
  WIFI_POWER_MINUS_1dBm, WIFI_POWER_2dBm,   WIFI_POWER_5dBm,    WIFI_POWER_7dBm,
  WIFI_POWER_8_5dBm,     WIFI_POWER_11dBm,  WIFI_POWER_13dBm,   WIFI_POWER_15dBm,
  WIFI_POWER_17dBm,      WIFI_POWER_18_5dBm, WIFI_POWER_19dBm,  WIFI_POWER_19_5dBm
};
const uint8_t TX_LEVEL_COUNT = sizeof(TX_LEVELS) / sizeof(TX_LEVELS[0]);
const uint8_t TX_MIN_IDX     = 1;
const char *const TX_DBM_TEXT[] = { "-1", "2", "5", "7", "8.5", "11", "13", "15", "17", "18.5", "19", "19.5" };
static_assert(sizeof(TX_DBM_TEXT) / sizeof(TX_DBM_TEXT[0]) == sizeof(TX_LEVELS) / sizeof(TX_LEVELS[0]),
              "TX_DBM_TEXT must match TX_LEVELS");

AdvSettings adv;
const char *advLoadNote    = nullptr;
bool        advApplyPending = false;
bool        advRestartAp    = false;

const unsigned long AP_IDLE_TIMEOUT_MS = 120000UL;
const unsigned long AP_CHECK_INTERVAL  = 1000UL;
unsigned long lastApClientSeen = 0;
unsigned long lastApCheck      = 0;

void advDefaults(AdvSettings &a)
{
  memset(&a, 0, sizeof(a));
  a.magic      = ADV_MAGIC;
  a.txIdx      = 4;
  a.channel    = 1;
  a.proto      = 1;
  a.maxClients = 4;
  a.autoOff    = 0;
  a.cpuMhz     = 80;
  a.dblMs      = 300;
  a.longMs     = 2000;
  strncpy(a.ssid, AP_SSID,     sizeof(a.ssid) - 1);
  strncpy(a.pass, AP_PASSWORD, sizeof(a.pass) - 1);
}

bool advIsDefault()
{
  AdvSettings d;
  advDefaults(d);
  return memcmp(&d, &adv, sizeof(d)) == 0;
}

bool advTextOk(const char *t, size_t minLen, size_t maxLen, bool allowQuotes)
{
  size_t n = strlen(t);
  if (n < minLen || n > maxLen) return false;

  for (size_t i = 0; i < n; i++)
  {
    char c = t[i];
    if (c < 32 || c > 126) return false;
    if (!allowQuotes && (c == '"' || c == '\\')) return false;
  }
  return true;
}

bool advValidate(const AdvSettings &a, const char **msg)
{
  if (a.cpuMhz != 80 && a.cpuMhz != 160 && a.cpuMhz != 240)
  { *msg = "CPU must be 80, 160 or 240 MHz"; return false; }

  if (a.txIdx < TX_MIN_IDX || a.txIdx >= TX_LEVEL_COUNT)
  { *msg = "Invalid TX power"; return false; }

  if (a.channel < 1 || a.channel > 13)
  { *msg = "Channel must be 1 to 13"; return false; }

  if (a.proto > 2)
  { *msg = "Invalid Wi-Fi mode"; return false; }

  if (a.maxClients < 1 || a.maxClients > 4)
  { *msg = "Max clients must be 1 to 4"; return false; }

  if (a.autoOff > 1)
  { *msg = "Invalid auto-off value"; return false; }

  if (a.dblMs < 200 || a.dblMs > 600)
  { *msg = "Double-click window 200 to 600 ms"; return false; }

  if (a.longMs < 1000 || a.longMs > 5000)
  { *msg = "Long press 1000 to 5000 ms"; return false; }

  if (!advTextOk(a.ssid, 1, 32, false))
  { *msg = "SSID: 1-32 plain characters, no quote or backslash"; return false; }

  if (a.pass[0] != '\0' && !advTextOk(a.pass, 8, 63, true))
  { *msg = "Password: empty (open) or 8 to 63 plain characters"; return false; }

  return true;
}

void applyAdvTiming()
{
  DOUBLE_CLICK_WINDOW  = adv.dblMs;
  LONG_PRESS_THRESHOLD = adv.longMs;
}

void loadAdv()
{
  advDefaults(adv);
  advLoadNote = nullptr;

  if (!preferences.begin("light_ctrl", false))
  {
    advLoadNote = "NVS open failed -> default advanced settings.";
    applyAdvTiming();
    return;
  }

  AdvSettings tmp;
  size_t len = preferences.getBytesLength("adv");

  if (len == sizeof(tmp) && preferences.getBytes("adv", &tmp, sizeof(tmp)) == sizeof(tmp))
  {
    tmp.ssid[sizeof(tmp.ssid) - 1] = '\0';
    tmp.pass[sizeof(tmp.pass) - 1] = '\0';

    if (tmp.txIdx < TX_MIN_IDX) tmp.txIdx = TX_MIN_IDX;

    const char *msg = "";
    if (tmp.magic == ADV_MAGIC && advValidate(tmp, &msg)) adv = tmp;
    else advLoadNote = "Invalid saved advanced settings -> defaults used.";
  }

  preferences.end();
  applyAdvTiming();
}

bool saveAdv()
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: advanced settings NOT persisted.");
    return false;
  }

  AdvSettings old;
  size_t got = preferences.getBytes("adv", &old, sizeof(old));
  bool ok = true;

  if (got != sizeof(adv) || memcmp(&old, &adv, sizeof(adv)) != 0)
  {
    ok = (preferences.putBytes("adv", &adv, sizeof(adv)) == sizeof(adv));
    if (ok) Serial.println("Advanced settings saved.");
    else    Serial.println("NVS write failed: advanced settings NOT persisted.");
  }

  preferences.end();
  return ok;
}

// ============================================================
//  RELAY OUTPUTS (per channel: pin, active level, open-drain)
// ============================================================

bool pinAllowed(int p)
{
  for (uint8_t i = 0; i < MAX_CH; i++) if (ALLOWED_PINS[i] == p) return true;
  return false;
}

bool pinUsedByChannel(int p, int except)
{
  for (uint8_t i = 0; i < chCount; i++)
    if ((int)i != except && chs[i].pin == p) return true;
  return false;
}

bool nameOk(const char *t)
{
  size_t n = strlen(t);
  if (n < 1 || n > 16) return false;
  for (size_t i = 0; i < n; i++)
  {
    char c = t[i];
    if (c < 32 || c > 126 || c == '"' || c == '\\') return false;
  }
  return true;
}

uint8_t channelOffLevel(const Channel &c) { return c.activeHigh ? LOW : HIGH; }

// Drive one switch pin.
//  Push-pull : normal digitalWrite HIGH / LOW.
//  Open-drain: LOW  = pin sinks to GND (OUTPUT, latch LOW)
//              HIGH = pin FLOATS (INPUT, high-impedance, no pull-up/down).
// Open-drain is done by switching the pin between INPUT and OUTPUT instead of
// relying on the OUTPUT_OPEN_DRAIN pad mode, so "release" is a real float on
// every GPIO (4, 13, 14, 17, 25, 26, 27, 32, 33 ... not only 16, 18, 23).
void drivePin(const Channel &c, uint8_t level)
{
  if (c.openDrain)
  {
    if (level == LOW)
    {
      digitalWrite(c.pin, LOW);          // latch LOW first -> no glitch
      pinMode(c.pin, OUTPUT);
    }
    else
    {
      pinMode(c.pin, INPUT);             // float
      gpio_set_pull_mode((gpio_num_t)c.pin, GPIO_FLOATING);   // no pull-up / pull-down
    }
  }
  else
  {
    digitalWrite(c.pin, level);
    pinMode(c.pin, OUTPUT);
    digitalWrite(c.pin, level);
  }
}

// RTC pads (4,13,14,25,26,27,32,33) can still be owned by the RTC block.
// Hand the pad back to the normal digital GPIO matrix before using it.
void releaseRtcPad(uint8_t pin)
{
  if (rtc_gpio_is_valid_gpio((gpio_num_t)pin)) rtc_gpio_deinit((gpio_num_t)pin);
}

void channelPinInit(Channel &c)
{
  releaseRtcPad(c.pin);
  drivePin(c, channelOffLevel(c));
  c.relay = false;
}

void initAllChannelPins()
{
  for (uint8_t i = 0; i < chCount; i++) channelPinInit(chs[i]);
}

void setChannelRelay(uint8_t i, bool state)
{
  Channel &c = chs[i];
  c.relay = state;
  bool level = c.activeHigh ? state : !state;
  drivePin(c, level ? HIGH : LOW);
}

void setRelay(bool state)
{
  for (uint8_t i = 0; i < chCount; i++) setChannelRelay(i, state);
}

void initializeRelaySafely()
{
  digitalWrite(DEFAULT_RELAY_PIN, HIGH);
  pinMode(DEFAULT_RELAY_PIN, OUTPUT_OPEN_DRAIN);
  digitalWrite(DEFAULT_RELAY_PIN, HIGH);
}

// ============================================================
//  FATAL ERROR
// ============================================================

[[noreturn]] void fatalError(const char *message)
{
  Serial.println();
  Serial.println("!!!!!!!!!! CRITICAL ERROR !!!!!!!!!!");
  Serial.println(message);
  Serial.println("Relays are OFF. Restarting in ~10 s...");

  bool ledUsable = (!pinUsedByChannel(STATUS_LED_PIN, -1) && STATUS_LED_PIN != BUTTON_PIN);

  if (ledUsable) pinMode(STATUS_LED_PIN, OUTPUT);

  for (uint8_t i = 0; i < 20; i++)
  {
    if (ledUsable) digitalWrite(STATUS_LED_PIN, (i % 2) ? LOW : HIGH);
    delay(500);
  }

  ESP.restart();
  while (true) { delay(1000); }
}

// ============================================================
//  TIME / SCHEDULE (per channel)
// ============================================================

bool isTimeValid(const DateTime &t)
{
  if (!t.isValid()) return false;
  if (t.year() < MIN_VALID_YEAR || t.year() > MAX_VALID_YEAR) return false;
  return true;
}

bool slotContains(const ScheduleSlot &s, int m)
{
  int on  = s.onH  * 60 + s.onM;
  int off = s.offH * 60 + s.offM;

  if (on < off) return (m >= on && m < off);
  return (m >= on || m < off);
}

bool stateAtMinute(const Channel &c, int m)
{
  m = ((m % 1440) + 1440) % 1440;

  for (uint8_t i = 0; i < c.schCount; i++)
  {
    if (c.sch[i].enabled && slotContains(c.sch[i], m)) return true;
  }
  return false;
}

DateTime latestTransition(const Channel &c, const DateTime &now, bool &isOn)
{
  int nowMin = now.hour() * 60 + now.minute();
  int best   = -1;

  for (uint8_t i = 0; i < c.schCount; i++)
  {
    if (!c.sch[i].enabled) continue;

    int ev[2] = { c.sch[i].onH  * 60 + c.sch[i].onM,
                  c.sch[i].offH * 60 + c.sch[i].offM };

    for (int k = 0; k < 2; k++)
    {
      int e = ev[k];
      if (stateAtMinute(c, e) == stateAtMinute(c, e - 1)) continue;

      int ago = (nowMin - e + 1440) % 1440;
      if (best < 0 || ago < best) best = ago;
    }
  }

  isOn = stateAtMinute(c, nowMin);

  if (best < 0) return DateTime(now.year(), now.month(), now.day(), 0, 0, 0);

  DateTime base(now.year(), now.month(), now.day(), now.hour(), now.minute(), 0);
  return base - TimeSpan((int32_t)best * 60);
}

bool isScheduleON(const Channel &c, const DateTime &now)
{
  return stateAtMinute(c, now.hour() * 60 + now.minute());
}

void makePeriodID(const Channel &c, const DateTime &now, char *buffer, size_t size)
{
  bool on;
  DateTime start = latestTransition(c, now, on);

  snprintf(buffer, size, "%04d%02d%02d_%02d%02d_%c",
           start.year(), start.month(), start.day(),
           start.hour(), start.minute(), on ? 'N' : 'F');
}

// ============================================================
//  CHANNEL + SCHEDULE STORAGE (NVS)
// ============================================================

bool scheduleValuesValid(int onH, int onM, int offH, int offM)
{
  if (onH < 0 || onH > 23 || offH < 0 || offH > 23) return false;
  if (onM < 0 || onM > 59 || offM < 0 || offM > 59) return false;
  if (onH * 60 + onM == offH * 60 + offM) return false;
  return true;
}

void useDefaultSchedule(Channel &c)
{
  memset(c.sch, 0, sizeof(c.sch));
  c.sch[0] = { DEFAULT_ON_HOUR, DEFAULT_ON_MINUTE,
               DEFAULT_OFF_HOUR, DEFAULT_OFF_MINUTE, 1 };
  c.schCount = 1;
}

const size_t CFG_REC         = 3 + 16;
const size_t CFG_BLOB_SIZE   = 1 + MAX_CH * CFG_REC;
const size_t SCHED_BLOB_SIZE = 1 + MAX_SCHEDULES * 5;

bool decodeSched(const uint8_t *blob, Channel &c)
{
  uint8_t n = blob[0];
  if (n < 1 || n > MAX_SCHEDULES) return false;

  for (uint8_t i = 0; i < n; i++)
  {
    const uint8_t *p = &blob[1 + i * 5];
    if (!scheduleValuesValid(p[0], p[1], p[2], p[3]) || p[4] > 1) return false;
  }

  memset(c.sch, 0, sizeof(c.sch));
  for (uint8_t i = 0; i < n; i++)
  {
    const uint8_t *p = &blob[1 + i * 5];
    c.sch[i] = { p[0], p[1], p[2], p[3], p[4] };
  }
  c.schCount = n;
  return true;
}

bool saveChannelConfig()
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: switch config NOT persisted.");
    return false;
  }

  uint8_t blob[CFG_BLOB_SIZE];
  memset(blob, 0, sizeof(blob));
  blob[0] = chCount;

  for (uint8_t i = 0; i < chCount; i++)
  {
    uint8_t *r = &blob[1 + i * CFG_REC];
    r[0] = chs[i].pin;
    r[1] = chs[i].activeHigh;
    r[2] = chs[i].openDrain;
    memcpy(&r[3], chs[i].name, 16);
  }

  uint8_t old[CFG_BLOB_SIZE];
  size_t got = preferences.getBytes("chcfg", old, sizeof(old));
  bool ok = true;

  if (got != CFG_BLOB_SIZE || memcmp(old, blob, CFG_BLOB_SIZE) != 0)
  {
    ok = (preferences.putBytes("chcfg", blob, CFG_BLOB_SIZE) == CFG_BLOB_SIZE);
    if (!ok) Serial.println("NVS write failed: switch config NOT persisted.");
  }

  preferences.end();
  return ok;
}

bool saveSchedule(uint8_t i)
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: schedule NOT persisted.");
    return false;
  }

  char key[8];
  snprintf(key, sizeof(key), "sch%u", i);

  uint8_t blob[SCHED_BLOB_SIZE];
  memset(blob, 0, sizeof(blob));
  blob[0] = chs[i].schCount;

  for (uint8_t k = 0; k < chs[i].schCount; k++)
  {
    uint8_t *p = &blob[1 + k * 5];
    p[0] = chs[i].sch[k].onH;
    p[1] = chs[i].sch[k].onM;
    p[2] = chs[i].sch[k].offH;
    p[3] = chs[i].sch[k].offM;
    p[4] = chs[i].sch[k].enabled;
  }

  uint8_t old[SCHED_BLOB_SIZE];
  size_t got = preferences.getBytes(key, old, sizeof(old));
  bool ok = true;

  if (got != SCHED_BLOB_SIZE || memcmp(old, blob, SCHED_BLOB_SIZE) != 0)
  {
    ok = (preferences.putBytes(key, blob, SCHED_BLOB_SIZE) == SCHED_BLOB_SIZE);
    if (!ok) Serial.println("NVS write failed: schedule NOT persisted.");
  }

  preferences.end();
  return ok;
}

void removeChannelKeys(uint8_t i)
{
  if (!preferences.begin("light_ctrl", false)) return;
  char key[8];
  snprintf(key, sizeof(key), "sch%u", i); preferences.remove(key);
  snprintf(key, sizeof(key), "m%u", i);   preferences.remove(key);
  snprintf(key, sizeof(key), "p%u", i);   preferences.remove(key);
  preferences.end();
}

void loadChannels()
{
  memset(chs, 0, sizeof(chs));
  chCount = 0;

  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed -> one default switch.");
    chCount = 1;
    chs[0].pin = DEFAULT_RELAY_PIN; chs[0].openDrain = 1;
    strcpy(chs[0].name, "Light");
    useDefaultSchedule(chs[0]);
    return;
  }

  uint8_t cfg[CFG_BLOB_SIZE];
  bool have = (preferences.getBytesLength("chcfg") == CFG_BLOB_SIZE &&
               preferences.getBytes("chcfg", cfg, CFG_BLOB_SIZE) == CFG_BLOB_SIZE);

  if (have)
  {
    uint8_t n = cfg[0];
    have = (n >= 1 && n <= MAX_CH);

    for (uint8_t i = 0; have && i < n; i++)
    {
      const uint8_t *r = &cfg[1 + i * CFG_REC];
      if (!pinAllowed(r[0]) || r[1] > 1 || r[2] > 1) { have = false; break; }
      for (uint8_t j = 0; j < i; j++) if (chs[j].pin == r[0]) have = false;
      if (!have) break;

      chs[i].pin = r[0]; chs[i].activeHigh = r[1]; chs[i].openDrain = r[2];
      memcpy(chs[i].name, &r[3], 16);
      chs[i].name[16] = '\0';
      if (!nameOk(chs[i].name)) snprintf(chs[i].name, sizeof(chs[i].name), "Switch %u", i + 1);
    }
    if (have) chCount = n;
  }

  if (!have)
  {
    memset(chs, 0, sizeof(chs));
    chCount = 1;
    chs[0].pin = DEFAULT_RELAY_PIN;
    chs[0].activeHigh = 0;
    chs[0].openDrain  = 1;
    strcpy(chs[0].name, "Light");
  }

  bool migrate = false;

  for (uint8_t i = 0; i < chCount; i++)
  {
    char key[8];
    snprintf(key, sizeof(key), "sch%u", i);

    uint8_t blob[SCHED_BLOB_SIZE];
    bool loaded = false;

    if (preferences.getBytesLength(key) == SCHED_BLOB_SIZE &&
        preferences.getBytes(key, blob, SCHED_BLOB_SIZE) == SCHED_BLOB_SIZE)
      loaded = decodeSched(blob, chs[i]);

    if (!loaded && i == 0)
    {
      if (preferences.getBytesLength("sched") == SCHED_BLOB_SIZE &&
          preferences.getBytes("sched", blob, SCHED_BLOB_SIZE) == SCHED_BLOB_SIZE &&
          decodeSched(blob, chs[0]))
      {
        loaded = true; migrate = true;
      }
    }

    if (!loaded && i == 0)
    {
      uint8_t onH  = preferences.getUChar("on_h",  DEFAULT_ON_HOUR);
      uint8_t onM  = preferences.getUChar("on_m",  DEFAULT_ON_MINUTE);
      uint8_t offH = preferences.getUChar("off_h", DEFAULT_OFF_HOUR);
      uint8_t offM = preferences.getUChar("off_m", DEFAULT_OFF_MINUTE);

      if (scheduleValuesValid(onH, onM, offH, offM))
      {
        memset(chs[0].sch, 0, sizeof(chs[0].sch));
        chs[0].sch[0] = { onH, onM, offH, offM, 1 };
        chs[0].schCount = 1;
        loaded = true; migrate = true;
      }
    }

    if (!loaded) useDefaultSchedule(chs[i]);
  }

  preferences.end();

  if (!have) saveChannelConfig();

  if (migrate && saveSchedule(0))
  {
    if (preferences.begin("light_ctrl", false))
    {
      preferences.remove("sched");
      preferences.remove("on_h");
      preferences.remove("on_m");
      preferences.remove("off_h");
      preferences.remove("off_m");
      preferences.end();
    }
    Serial.println("Old schedule migrated to switch #1.");
  }
}

// ============================================================
//  Wi-Fi AP STATE STORAGE (NVS)
// ============================================================

bool loadApState()
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed -> default AP state used.");
    return AP_DEFAULT_ON;
  }

  uint8_t v = preferences.getUChar("ap_on", 255);
  preferences.end();

  if (v == 0) return false;
  if (v == 1) return true;

  if (v != 255) Serial.println("Invalid saved AP state -> default used.");
  return AP_DEFAULT_ON;
}

bool saveApState(bool on)
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: AP state NOT persisted.");
    return false;
  }

  bool ok = true;
  uint8_t saved = preferences.getUChar("ap_on", 255);

  if (saved != (on ? 1 : 0))
  {
    ok = (preferences.putUChar("ap_on", on ? 1 : 0) == 1);
    if (ok) Serial.println(on ? "AP state saved: ON" : "AP state saved: OFF");
    else    Serial.println("NVS write failed: AP state NOT persisted.");
  }

  preferences.end();
  return ok;
}

// ============================================================
//  OVERRIDE STORAGE (NVS)
// ============================================================

const char *overrideName(OverrideMode m)
{
  switch (m)
  {
    case AUTO_MODE: return "AUTO";
    case FORCE_ON:  return "FORCE_ON";
    case FORCE_OFF: return "FORCE_OFF";
    default:        return "UNKNOWN";
  }
}

void printOverrideMode(uint8_t i)
{
  Serial.printf("Override [%s]: %s\n", chs[i].name, overrideName(chs[i].ovr));
}

bool eraseStoredOverride(uint8_t i)
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: stored override not cleared.");
    return false;
  }

  char km[8], kp[8];
  snprintf(km, sizeof(km), "m%u", i);
  snprintf(kp, sizeof(kp), "p%u", i);

  bool ok = true;

  uint8_t savedMode = preferences.getUChar(km, AUTO_MODE);
  char savedPeriod[20] = "";
  size_t periodLength = preferences.getString(kp, savedPeriod, sizeof(savedPeriod));

  if (savedMode != AUTO_MODE || periodLength > 0)
  {
    if (savedMode != AUTO_MODE && preferences.putUChar(km, AUTO_MODE) != 1) ok = false;
    if (periodLength > 0 && !preferences.remove(kp)) ok = false;
    if (!ok) Serial.println("NVS write failed: stored override NOT cleared.");
  }

  preferences.end();
  return ok;
}

bool saveOverride(uint8_t i)
{
  Channel &c = chs[i];

  if (!c.schedOn)
  {
    bool erased = eraseStoredOverride(i);
    Serial.println("OFF period: override kept in RAM only (not saved to NVS).");
    printOverrideMode(i);
    return erased;
  }

  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: override NOT persisted.");
    return false;
  }

  char km[8], kp[8];
  snprintf(km, sizeof(km), "m%u", i);
  snprintf(kp, sizeof(kp), "p%u", i);

  uint8_t savedMode = preferences.getUChar(km, 255);
  char savedPeriod[20] = "";
  preferences.getString(kp, savedPeriod, sizeof(savedPeriod));

  bool modeChanged   = (savedMode != (uint8_t)c.ovr);
  bool periodChanged = (strcmp(savedPeriod, c.period) != 0);

  bool ok = true;

  if (modeChanged   && preferences.putUChar(km, (uint8_t)c.ovr) != 1) ok = false;
  if (periodChanged && preferences.putString(kp, c.period) == 0)      ok = false;

  preferences.end();

  if (!ok) Serial.println("NVS write failed: override NOT persisted.");
  else if (modeChanged || periodChanged)
  {
    Serial.println("Override state saved.");
    printOverrideMode(i);
  }

  return ok;
}

void clearStoredOverride(uint8_t i)
{
  chs[i].ovr = AUTO_MODE;
  eraseStoredOverride(i);
}

void loadOverride(uint8_t i)
{
  Channel &c = chs[i];
  c.ovr = AUTO_MODE;

  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed -> AUTO mode.");
    return;
  }

  char km[8], kp[8];
  snprintf(km, sizeof(km), "m%u", i);
  snprintf(kp, sizeof(kp), "p%u", i);

  uint8_t savedMode = preferences.getUChar(km, AUTO_MODE);
  char savedPeriod[20] = "";
  size_t periodLength = preferences.getString(kp, savedPeriod, sizeof(savedPeriod));

  preferences.end();

  if (!c.schedOn)
  {
    if (savedMode != AUTO_MODE || periodLength > 0)
    {
      Serial.println("OFF period -> persisted override ignored and cleared.");
      clearStoredOverride(i);
    }
    c.ovr = AUTO_MODE;
    return;
  }

  if (savedMode == AUTO_MODE && periodLength == 0) return;

  if (savedMode > FORCE_OFF)
  {
    Serial.println("Invalid saved override -> cleared.");
    clearStoredOverride(i);
    return;
  }

  if (savedMode == AUTO_MODE || periodLength == 0 || strcmp(savedPeriod, c.period) != 0)
  {
    Serial.println("Saved override expired -> cleared.");
    clearStoredOverride(i);
    return;
  }

  c.ovr = (OverrideMode)savedMode;
  Serial.printf("Current-period override restored [%s].\n", c.name);
}

// ============================================================
//  APPLY STATE
// ============================================================

void applyChannelState(uint8_t i)
{
  Channel &c = chs[i];
  if (c.ovr == FORCE_ON)       setChannelRelay(i, true);
  else if (c.ovr == FORCE_OFF) setChannelRelay(i, false);
  else                         setChannelRelay(i, c.schedOn);
}

void applyCurrentState()
{
  for (uint8_t i = 0; i < chCount; i++) applyChannelState(i);
}

void handleScheduleChange(const DateTime &now)
{
  for (uint8_t i = 0; i < chCount; i++)
  {
    Channel &c = chs[i];
    char newPeriodID[20];
    makePeriodID(c, now, newPeriodID, sizeof(newPeriodID));

    c.schedOn = isScheduleON(c, now);

    if (strcmp(newPeriodID, c.period) == 0) continue;

    Serial.printf("\n===== NEW SCHEDULE PERIOD [%s] =====\nOld: %s\nNew: %s\n",
                  c.name, c.period, newPeriodID);

    strncpy(c.period, newPeriodID, sizeof(c.period) - 1);
    c.period[sizeof(c.period) - 1] = '\0';

    if (c.ovr != AUTO_MODE)
    {
      clearStoredOverride(i);
      Serial.println("Manual override expired -> AUTO.");
    }

    setChannelRelay(i, c.schedOn);
  }
}

// ============================================================
//  RTC
// ============================================================

bool rtcResponding()
{
  Wire.beginTransmission(RTC_I2C_ADDRESS);
  return (Wire.endTransmission() == 0);
}

bool readRTC(DateTime &result, const char **reason)
{
  if (!rtcResponding())  { *reason = "DS3231 I2C not responding"; return false; }
  if (rtc.lostPower())   { *reason = "DS3231 lost power";         return false; }

  DateTime t = rtc.now();
  if (!isTimeValid(t))   { *reason = "Invalid RTC time";          return false; }

  result = t;
  return true;
}

void markRTCFailed(const char *reason);

bool readFreshRTC(DateTime &result)
{
  if (!rtcAvailable) return false;

  const char *reason = "";

  if (!readRTC(result, &reason))
  {
    markRTCFailed(reason);
    return false;
  }

  return true;
}

void markRTCFailed(const char *reason)
{
  bool wasAvailable = rtcAvailable;

  rtcAvailable = false;
  setRelay(false);

  if (wasAvailable)
  {
    Serial.println();
    Serial.println("===== RTC FAILURE =====");
    Serial.print("Reason: ");
    Serial.println(reason);
    Serial.println("All relays forced OFF.");

    lastRTCRecoveryAttempt = millis();
    rtcFailureLogged = false;
  }
}

void updateRTC()
{
  if (!rtcAvailable) return;             // tryRecoverRTC() handles the failed state
  if (millis() - lastRTCRead < RTC_READ_INTERVAL) return;
  lastRTCRead = millis();

  DateTime newTime;
  const char *reason = "";

  if (!readRTC(newTime, &reason))
  {
    markRTCFailed(reason);
    return;
  }

  currentTime = newTime;

  // Schedules only change on a minute boundary: evaluate once per minute.
  uint32_t key = newTime.unixtime() / 60;
  if (key != lastEvalMinute)
  {
    lastEvalMinute = key;
    handleScheduleChange(newTime);
  }
}

bool recoverI2CBus()
{
  Wire.end();
  delay(2);

  pinMode(SDA_PIN, INPUT_PULLUP);
  pinMode(SCL_PIN, INPUT_PULLUP);
  delay(1);

  for (uint8_t i = 0; i < 9; i++)
  {
    if (digitalRead(SDA_PIN) == HIGH) break;

    pinMode(SCL_PIN, OUTPUT);
    digitalWrite(SCL_PIN, LOW);
    delayMicroseconds(5);
    pinMode(SCL_PIN, INPUT_PULLUP);
    delayMicroseconds(5);
  }

  pinMode(SDA_PIN, OUTPUT);
  digitalWrite(SDA_PIN, LOW);
  delayMicroseconds(5);
  pinMode(SCL_PIN, INPUT_PULLUP);
  delayMicroseconds(5);
  pinMode(SDA_PIN, INPUT_PULLUP);
  delayMicroseconds(5);

  bool busFree = (digitalRead(SDA_PIN) == HIGH) && (digitalRead(SCL_PIN) == HIGH);

  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(100000);
  delay(2);

  return busFree;
}

bool initializeRTC(DateTime &timeOut, const char **reason)
{
  if (!rtc.begin())
  {
    *reason = "DS3231 not detected";
    return false;
  }

  Wire.setClock(100000);

  return readRTC(timeOut, reason);
}

void startWithTrustedTime(const DateTime &t)
{
  currentTime = t;

  for (uint8_t i = 0; i < chCount; i++)
  {
    chs[i].schedOn = isScheduleON(chs[i], t);
    makePeriodID(chs[i], t, chs[i].period, sizeof(chs[i].period));
  }

  rtcAvailable = true;
  rtcFailureLogged = false;
  lastRTCRead = millis();
  lastEvalMinute = t.unixtime() / 60;

  for (uint8_t i = 0; i < chCount; i++) loadOverride(i);
  applyCurrentState();

  for (uint8_t i = 0; i < chCount; i++)
  {
    Serial.printf("State restored [%s, GPIO %u]: schedule %s, override %s, relay %s, period %s\n",
                  chs[i].name, chs[i].pin,
                  chs[i].schedOn ? "ON" : "OFF",
                  overrideName(chs[i].ovr),
                  chs[i].relay ? "ON" : "OFF",
                  chs[i].period);
  }
}

void tryRecoverRTC()
{
  if (rtcAvailable) return;
  if (millis() - lastRTCRecoveryAttempt < RTC_RECOVERY_INTERVAL) return;

  lastRTCRecoveryAttempt = millis();

  if (!rtcFailureLogged) Serial.println("Attempting I2C bus recovery...");
  bool busFree = recoverI2CBus();

  DateTime t;
  const char *reason = "";

  if (!initializeRTC(t, &reason))
  {
    if (!rtcFailureLogged)
    {
      Serial.print("RTC recovery failed: ");
      Serial.print(reason);
      Serial.print(busFree ? "  [I2C bus free]" : "  [I2C bus STUCK]");
      Serial.println("  (retrying every 5 s, no more messages until recovered)");
      rtcFailureLogged = true;
    }
    setRelay(false);
    return;
  }

  rtcFailureLogged = false;
  startWithTrustedTime(t);
  Serial.println("RTC recovered successfully.");
}

bool syncRTC(int y, int mo, int d, int h, int mi, int s, const char **msg)
{
  if (y < MIN_VALID_YEAR || y > MAX_VALID_YEAR ||
      mo < 1 || mo > 12 || d < 1 || d > 31 ||
      h < 0 || h > 23 || mi < 0 || mi > 59 || s < 0 || s > 59)
  {
    *msg = "Invalid phone time";
    return false;
  }

  DateTime t(y, mo, d, h, mi, s);

  if (t.year() != y || t.month() != mo || t.day() != d)
  {
    *msg = "Invalid phone date";
    return false;
  }

  if (!rtcAvailable)
  {
    if (!rtc.begin())
    {
      *msg = "DS3231 not detected";
      return false;
    }
    Wire.setClock(100000);
  }

  if (!rtcResponding())
  {
    *msg = "DS3231 not responding";
    return false;
  }

  rtc.adjust(t);

  DateTime verified;
  const char *reason = "";

  if (!readRTC(verified, &reason))
  {
    if (rtcAvailable) markRTCFailed(reason);
    *msg = "RTC write/readback failed";
    return false;
  }

  if (!rtcAvailable) startWithTrustedTime(verified);
  else
  {
    currentTime = verified;
    lastEvalMinute = verified.unixtime() / 60;
    handleScheduleChange(verified);
  }

  Serial.println("RTC synchronized from phone.");
  *msg = "RTC synchronized";
  return true;
}

// ============================================================
//  MANUAL CONTROL
// ============================================================

bool commitOverride(uint8_t i, OverrideMode mode)
{
  Channel &c = chs[i];

  if (c.ovr == mode)                      // already in this mode: nothing to do
  {
    applyChannelState(i);
    return true;
  }

  if (mode == AUTO_MODE)
  {
    c.ovr = AUTO_MODE;
    bool ok = eraseStoredOverride(i);
    c.schedOn = isScheduleON(c, currentTime);
    applyChannelState(i);
    return ok;
  }

  c.ovr = mode;
  applyChannelState(i);
  return saveOverride(i);
}

bool applyManualOverride(int idx, OverrideMode mode, const char **msg)
{
  if (!rtcAvailable)
  {
    setRelay(false);
    *msg = "RTC unavailable";
    return false;
  }

  bool saved = true;

  if (idx < 0)
  {
    for (uint8_t i = 0; i < chCount; i++) saved = commitOverride(i, mode) && saved;
  }
  else saved = commitOverride((uint8_t)idx, mode);

  if (mode == AUTO_MODE)      *msg = saved ? "AUTO mode"  : "AUTO mode (NVS clear failed)";
  else if (mode == FORCE_ON)  *msg = saved ? "Forced ON"  : "Forced ON (NVS save failed)";
  else                        *msg = saved ? "Forced OFF" : "Forced OFF (NVS save failed)";

  return true;
}

bool setSchedules(uint8_t idx, const ScheduleSlot *in, uint8_t n, const char **msg)
{
  if (n < 1 || n > MAX_SCHEDULES)
  {
    *msg = "Need 1 to 10 schedules";
    return false;
  }

  for (uint8_t i = 0; i < n; i++)
  {
    if (!scheduleValuesValid(in[i].onH, in[i].onM, in[i].offH, in[i].offM))
    {
      *msg = "Invalid times (ON and OFF must differ)";
      return false;
    }
  }

  Channel &c = chs[idx];

  ScheduleSlot fresh[MAX_SCHEDULES];
  memset(fresh, 0, sizeof(fresh));
  for (uint8_t i = 0; i < n; i++) fresh[i] = in[i];

  if (c.schCount == n && memcmp(c.sch, fresh, sizeof(fresh)) == 0)
  {
    *msg = "No changes";
    return true;
  }

  memcpy(c.sch, fresh, sizeof(fresh));
  c.schCount = n;

  bool saved = saveSchedule(idx);
  cfgVersion++;

  bool rtcOk = rtcAvailable;
  if (rtcOk) handleScheduleChange(currentTime);

  if (!saved)
  {
    *msg = "Schedules applied but NVS save FAILED";
    return false;
  }

  *msg = rtcOk ? "Schedules saved" : "Schedules saved (applies when RTC is back)";
  return true;
}

// ============================================================
//  BUTTON
// ============================================================

void executeLongPress()
{
  factoryResetRequested = true;
  Serial.println("Long press -> SYSTEM RESET requested");
}

void checkButton()
{
  bool reading = digitalRead(BUTTON_PIN);

  if (reading != lastButtonReading) lastDebounceTime = millis();

  if (millis() - lastDebounceTime > DEBOUNCE_DELAY && reading != stableButtonState)
  {
    stableButtonState = reading;

    if (stableButtonState == LOW)
    {
      buttonIsPressed = true;
      buttonPressStartTime = millis();

      if (clickCount > 0)
      {
        if (clickCount < 2) clickCount++;
        longPressHandled = true;
      }
      else longPressHandled = false;
    }
    else if (buttonIsPressed)
    {
      buttonIsPressed = false;

      if (clickCount > 0) pendingClickTime = millis();
      else if (!longPressHandled)
      {
        clickCount = 1;
        pendingClickTime = millis();
      }
    }
  }

  if (clickCount > 0 && reading == HIGH && !buttonIsPressed &&
      millis() - pendingClickTime > DOUBLE_CLICK_WINDOW)
  {
    uint8_t n = clickCount;
    clickCount = 0;

    if (n >= 2)
    {
      wifiToggleRequested = true;
      Serial.println("Double click -> Wi-Fi AP toggle requested");
    }
  }

  if (buttonIsPressed && !longPressHandled &&
      millis() - buttonPressStartTime >= LONG_PRESS_THRESHOLD)
  {
    longPressHandled = true;
    clickCount = 0;
    executeLongPress();
  }

  lastButtonReading = reading;
}

// ============================================================
//  ROUTER Wi-Fi (STATION) + mDNS
// ============================================================

const char *MDNS_NAME = "esplight";

String staSsid, staPass;
bool   staWanted           = false;
bool   staConnecting       = false;
bool   staWasConnected     = false;
bool   staConnectRequested = false;
bool   staForgetRequested  = false;
bool   mdnsStarted         = false;
bool   serverRunning       = false;

unsigned long staConnectStart = 0;
unsigned long lastStaRetry    = 0;

const unsigned long STA_CONNECT_TIMEOUT     = 15000UL;
const unsigned long STA_RETRY_INTERVAL      = 10000UL;   // no phone on the AP: retry router quickly
const unsigned long STA_RETRY_INTERVAL_BUSY = 300000UL;

void startServerIfNeeded()
{
  if (!serverRunning) { server.begin(); serverRunning = true; }
}

// Radio must never doze between packets: default modem-sleep adds 100-300 ms
// to every request and drops packets. Call after every WiFi.mode()/begin().
void wifiLowLatency()
{
  WiFi.setSleep(false);
}

wifi_mode_t wifiIdleMode()
{
  return staWanted ? WIFI_STA : WIFI_OFF;
}

bool staSsidOk(const String &s)
{
  if (s.length() < 1 || s.length() > 32) return false;
  for (size_t i = 0; i < s.length(); i++)
  {
    unsigned char c = s[i];
    if (c < 32 || c == 127 || c == '"' || c == '\\') return false;
  }
  return true;
}

void loadSta()
{
  staSsid = ""; staPass = ""; staWanted = false;

  if (!preferences.begin("light_ctrl", false)) return;
  staSsid = preferences.getString("sta_ssid", "");
  staPass = preferences.getString("sta_pass", "");
  preferences.end();

  bool passOk = (staPass.length() == 0) || (staPass.length() >= 8 && staPass.length() <= 63);
  staWanted = staSsidOk(staSsid) && passOk;
  if (!staWanted) { staSsid = ""; staPass = ""; }
}

bool saveSta(const String &s, const String &p)
{
  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: router NOT persisted.");
    return false;
  }

  bool ok = (preferences.putString("sta_ssid", s.c_str()) == s.length());
  if (p.length() > 0) ok = ok && (preferences.putString("sta_pass", p.c_str()) == p.length());
  else                preferences.remove("sta_pass");

  preferences.end();
  if (!ok) Serial.println("NVS write failed: router NOT persisted.");
  return ok;
}

bool forgetSta()
{
  if (!preferences.begin("light_ctrl", false)) return false;
  preferences.remove("sta_ssid");
  preferences.remove("sta_pass");
  preferences.end();
  return true;
}

void startMdns()
{
  if (mdnsStarted) return;
  if (MDNS.begin(MDNS_NAME))
  {
    MDNS.addService("http", "tcp", 80);
    mdnsStarted = true;
    Serial.println("mDNS: http://esplight.local/");
  }
  else Serial.println("mDNS start failed.");
}

void stopMdns()
{
  if (mdnsStarted) { MDNS.end(); mdnsStarted = false; }
}

void beginStaConnect()
{
  if (!staWanted) return;

  WiFi.persistent(false);
  WiFi.setHostname(MDNS_NAME);
  WiFi.mode(apEnabled ? WIFI_AP_STA : WIFI_STA);
  WiFi.setAutoReconnect(false);
  WiFi.begin(staSsid.c_str(), staPass.c_str());
  WiFi.setTxPower(TX_LEVELS[adv.txIdx]);
  wifiLowLatency();

  staConnecting   = true;
  staConnectStart = millis();
  lastStaRetry    = millis();

  Serial.print("Router connect: ");
  Serial.println(staSsid);
}

void staService()
{
  if (!staWanted) return;

  unsigned long now = millis();

  if (WiFi.status() == WL_CONNECTED)
  {
    if (!staWasConnected)
    {
      staWasConnected = true;
      staConnecting   = false;
      wifiLowLatency();
      stopMdns();
      startMdns();
      startServerIfNeeded();
      Serial.print("Router connected. IP: ");
      Serial.println(WiFi.localIP());
    }
    return;
  }

  if (staWasConnected)
  {
    staWasConnected = false;
    stopMdns();
    Serial.println("Router connection lost.");
    lastStaRetry = now - STA_RETRY_INTERVAL + 1000;
  }

  if (staConnecting)
  {
    if (now - staConnectStart >= STA_CONNECT_TIMEOUT)
    {
      staConnecting = false;
      lastStaRetry  = now;
      WiFi.disconnect(false);
      Serial.println("Router connect timeout (wrong password or out of range).");
    }
    return;
  }

  unsigned long every = (apEnabled && WiFi.softAPgetStationNum() > 0)
                        ? STA_RETRY_INTERVAL_BUSY : STA_RETRY_INTERVAL;

  if (now - lastStaRetry >= every) beginStaConnect();
}

void applyStaRequests()
{
  if (staForgetRequested)
  {
    staForgetRequested = false;
    staConnectRequested = false;
    stopMdns();
    staConnecting = false;
    staWasConnected = false;
    WiFi.disconnect(false, true);

    if (apEnabled) WiFi.mode(WIFI_AP);
    else { server.stop(); serverRunning = false; WiFi.mode(WIFI_OFF); }

    Serial.println("Router forgotten.");
  }

  if (staConnectRequested)
  {
    staConnectRequested = false;
    stopMdns();
    staWasConnected = false;
    WiFi.disconnect(false);
    delay(100);
    beginStaConnect();
    startServerIfNeeded();
  }
}

// ============================================================
//  STATUS (serial)
// ============================================================

void printStatus()
{
  Serial.println();
  Serial.println("================================");
  Serial.println("            STATUS");
  Serial.println("================================");

  Serial.print("RTC: ");
  if (rtcAvailable)
  {
    Serial.printf("%04d-%02d-%02d %02d:%02d:%02d\n",
                  currentTime.year(), currentTime.month(), currentTime.day(),
                  currentTime.hour(), currentTime.minute(), currentTime.second());
  }
  else Serial.println("UNAVAILABLE");

  for (uint8_t k = 0; k < chCount; k++)
  {
    const Channel &c = chs[k];
    Serial.printf("--- Switch %u \"%s\"  GPIO %u  %s  %s ---\n",
                  k + 1, c.name, c.pin,
                  c.activeHigh ? "active HIGH" : "active LOW",
                  c.openDrain ? "open-drain" : "push-pull");

    for (uint8_t i = 0; i < c.schCount; i++)
    {
      Serial.printf("  #%u  ON %02u:%02u  OFF %02u:%02u  %s\n",
                    i + 1, c.sch[i].onH, c.sch[i].onM,
                    c.sch[i].offH, c.sch[i].offM,
                    c.sch[i].enabled ? "enabled" : "disabled");
    }

    Serial.printf("  Schedule: %s   Override: %s   Relay: %s\n",
                  rtcAvailable ? (c.schedOn ? "ON" : "OFF") : "UNKNOWN",
                  overrideName(c.ovr), c.relay ? "ON" : "OFF");
    Serial.printf("  Period ID: %s\n", rtcAvailable ? c.period : "UNKNOWN");
  }

  if (apEnabled && (WiFi.getMode() & WIFI_AP))
  {
    Serial.printf("Wi-Fi AP: ON  (%s, %s)  ch %u  clients: %d\n",
                  adv.ssid, adv.pass[0] ? "secured" : "open",
                  adv.channel, WiFi.softAPgetStationNum());
  }
  else Serial.println("Wi-Fi AP: OFF");

  if (!staWanted) Serial.println("Router: not set");
  else if (WiFi.status() == WL_CONNECTED)
  {
    Serial.print("Router: ");
    Serial.print(staSsid);
    Serial.print("  IP: ");
    Serial.println(WiFi.localIP());
  }
  else
  {
    Serial.print("Router: ");
    Serial.print(staSsid);
    Serial.println(staConnecting ? "  (connecting)" : "  (disconnected)");
  }

  Serial.println("================================");
}

// ============================================================
//  SERIAL COMMANDS
// ============================================================

void clearSerialBuffer()
{
  serialIndex = 0;
  serialBuffer[0] = '\0';
}

void executeSerialCommand(const char *command)
{
  if (strcmp(command, "STATUS") == 0)
  {
    printStatus();
    return;
  }

  if (strcmp(command, "HELP") == 0)
  {
    Serial.println();
    Serial.println("Commands:");
    Serial.println("AUTO [n] - Clear manual override (all switches, or switch n)");
    Serial.println("ON [n]   - Force ON  (this period)");
    Serial.println("OFF [n]  - Force OFF (this period)");
    Serial.println("STATUS   - Show status");
    Serial.println("HELP     - Show commands");
    Serial.println("ADVRESET   - Restore advanced Wi-Fi/CPU settings to defaults");
    Serial.println("WIFIFORGET - Forget the saved router");
    Serial.println("FACTORYRESET - Erase ALL saved data (NVS) and restart");
    Serial.println("Button: double click = Wi-Fi AP on/off,");
    Serial.println("        hold 2 s = SYSTEM RESET (erase all data)");
    return;
  }

  if (strcmp(command, "FACTORYRESET") == 0)
  {
    factoryResetRequested = true;
    Serial.println("SYSTEM RESET requested.");
    return;
  }

  if (strcmp(command, "ADVRESET") == 0)
  {
    if (advIsDefault())
    {
      Serial.println("Advanced settings already at defaults.");
      return;
    }
    advDefaults(adv);
    applyAdvTiming();
    bool ok = saveAdv();
    advApplyPending = true;
    advRestartAp    = true;
    Serial.println(ok ? "Advanced settings reset to defaults (SSID LIGHT, no password)."
                      : "Advanced settings reset (NVS save FAILED).");
    return;
  }

  if (strcmp(command, "WIFIFORGET") == 0)
  {
    forgetSta();
    staSsid = ""; staPass = ""; staWanted = false;
    staForgetRequested = true;
    Serial.println("Router forgotten.");
    return;
  }

  char cmd[sizeof(serialBuffer)];
  strncpy(cmd, command, sizeof(cmd));
  cmd[sizeof(cmd) - 1] = '\0';

  int idx = -1;
  char *sp = strchr(cmd, ' ');
  if (sp)
  {
    *sp = '\0';
    idx = atoi(sp + 1) - 1;
    if (idx < 0 || idx >= chCount)
    {
      Serial.println("Bad switch number.");
      return;
    }
  }

  OverrideMode mode;

  if      (strcmp(cmd, "AUTO") == 0) mode = AUTO_MODE;
  else if (strcmp(cmd, "ON")   == 0) mode = FORCE_ON;
  else if (strcmp(cmd, "OFF")  == 0) mode = FORCE_OFF;
  else
  {
    Serial.println("Unknown command. Type HELP.");
    return;
  }

  const char *msg;
  applyManualOverride(idx, mode, &msg);
  Serial.println(msg);
}

void finishSerialLine()
{
  while (serialIndex > 0 && serialBuffer[serialIndex - 1] == ' ')
  {
    serialIndex--;
  }

  if (serialIndex == 0)
  {
    clearSerialBuffer();
    return;
  }

  serialBuffer[serialIndex] = '\0';

  char command[sizeof(serialBuffer)];
  strncpy(command, serialBuffer, sizeof(command));
  command[sizeof(command) - 1] = '\0';

  clearSerialBuffer();
  executeSerialCommand(command);
}

void handleSerialCommands()
{
  uint8_t processed = 0;

  while (Serial.available() > 0 && processed < SERIAL_MAX_CHARS_PER_CYCLE)
  {
    int raw = Serial.read();
    if (raw < 0) break;

    processed++;
    lastSerialCharacterTime = millis();

    char c = (char)raw;

    if (c == '\n' || c == '\r')
    {
      if (serialOverflow)
      {
        serialOverflow = false;
        clearSerialBuffer();
      }
      else finishSerialLine();
      continue;
    }

    if (serialOverflow) continue;

    if (c == '\t') c = ' ';
    if (c < 32 || c > 126) continue;
    if (c == ' ' && serialIndex == 0) continue;

    if (serialIndex >= sizeof(serialBuffer) - 1)
    {
      Serial.println("Command too long.");
      clearSerialBuffer();
      serialOverflow = true;
      continue;
    }

    if (c >= 'a' && c <= 'z') c -= ('a' - 'A');
    serialBuffer[serialIndex++] = c;
    serialBuffer[serialIndex] = '\0';
  }

  if ((serialIndex > 0 || serialOverflow) &&
      millis() - lastSerialCharacterTime > SERIAL_INPUT_TIMEOUT)
  {
    clearSerialBuffer();
    serialOverflow = false;
  }
}

// ============================================================
//  WEB UI PAGE (FLASH PROGMEM)
// ============================================================

const char INDEX_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#4f46e5">
<title>LIGHT Controller</title>
<style>
:root{color-scheme:light dark;--bg:#f5f6fa;--card:#fff;--tx:#111827;--mu:#6b7280;--ln:#e5e7eb;--in:#f9fafb;--pr:#4f46e5;--prs:#eef2ff;--ok:#059669;--okb:#d1fae5;--er:#dc2626;--erb:#fee2e2;--wa:#b45309;--wab:#fef3c7;--sh:0 1px 2px rgba(17,24,39,.05),0 8px 24px rgba(17,24,39,.06)}
@media(prefers-color-scheme:dark){:root{--bg:#0b0f1a;--card:#141a2a;--tx:#e8eaf0;--mu:#9aa3b5;--ln:#252d42;--in:#0f1424;--pr:#818cf8;--prs:#1e2347;--ok:#34d399;--okb:#0f3a2c;--er:#f87171;--erb:#3f1b1b;--wa:#fbbf24;--wab:#3b2d0c;--sh:0 1px 2px rgba(0,0,0,.4)}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:var(--bg);color:var(--tx);-webkit-text-size-adjust:100%}
.top{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:12px;padding:calc(12px + env(safe-area-inset-top)) 18px 12px;background:var(--card);border-bottom:1px solid var(--ln)}
.logo{width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,#4f46e5,#06b6d4);display:grid;place-items:center;flex:none}
.logo svg{width:21px;height:21px;fill:#fff}
.brand{flex:1;line-height:1.2}
.brand b{display:block;font-size:1.02rem}
.brand span{font-size:.72rem;color:var(--mu)}
.temp{font-size:.74rem;font-weight:700;padding:5px 11px;border-radius:999px;background:var(--okb);color:var(--ok);font-variant-numeric:tabular-nums;white-space:nowrap}
.temp.warm{background:var(--wab);color:var(--wa)}
.temp.hot{background:var(--erb);color:var(--er)}
main{max-width:540px;margin:0 auto;padding:6px 16px 120px}
.pane{display:none}
body[data-t=home] .pane[data-t=home],body[data-t=sched] .pane[data-t=sched],body[data-t=net] .pane[data-t=net],body[data-t=set] .pane[data-t=set]{display:block}
.card{background:var(--card);border:1px solid var(--ln);border-radius:18px;padding:18px;margin:14px 0;box-shadow:var(--sh)}
h2{margin:0 0 14px;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--mu)}
.page-t{margin:20px 2px 2px;font-size:1.35rem;font-weight:700}
.page-s{margin:0 2px;font-size:.85rem;color:var(--mu)}
.rtc-card{border:0;color:#fff;text-align:center;padding:26px 18px;background:radial-gradient(120% 140% at 0% 0%,#6366f1 0%,#4338ca 45%,#0e7490 100%)}
.rtc-title{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.16em;opacity:.8}
.big{font-size:clamp(1.3rem,6.2vw,2rem);white-space:nowrap;font-weight:700;margin-top:8px;font-variant-numeric:tabular-nums}
.on,.off{display:inline-block;padding:3px 12px;border-radius:999px;font-size:.78rem;font-weight:700}
.on{background:var(--okb);color:var(--ok)}
.off{background:var(--erb);color:var(--er)}
.row{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:11px 0;border-bottom:1px solid var(--ln);font-size:.9rem}
.row>:first-child{color:var(--mu)}
button{font:inherit;font-size:.93rem;font-weight:600;width:100%;padding:13px;margin:10px 0 0;border:0;border-radius:12px;background:var(--pr);color:#fff;cursor:pointer;transition:filter .15s,transform .06s}
button:hover{filter:brightness(1.07)}
button:active{transform:scale(.98)}
button:disabled{opacity:.45;cursor:not-allowed}
.b-off{background:#dc2626}
.b-auto{background:var(--in);color:var(--tx);border:1px solid var(--ln)}
.b-auto.act{background:var(--pr);color:#fff;border-color:var(--pr)}
.b-add{background:var(--prs);color:var(--pr)}
select,input[type=text],input[type=password],input[type=number]{width:100%;padding:12px 13px;font:inherit;font-size:.93rem;border:1px solid var(--ln);border-radius:12px;background:var(--in);color:var(--tx)}
select:focus,input:focus{outline:2px solid var(--pr);outline-offset:1px}
input:disabled{opacity:.5}
input[type=checkbox]{-webkit-appearance:none;appearance:none;width:44px;height:26px;margin:0;padding:0;border:0;border-radius:999px;background:#9ca3af;position:relative;flex:none;cursor:pointer;transition:background .2s}
input[type=checkbox]::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .2s}
input[type=checkbox]:checked{background:var(--ok)}
input[type=checkbox]:checked::after{left:21px}
.sch{border:1px solid var(--ln);border-radius:16px;padding:14px;margin:12px 0;background:var(--in)}
.sh{display:flex;align-items:center;gap:10px}
.sh label{flex:1;display:flex;align-items:center;gap:9px;font-size:.84rem;color:var(--mu)}
.num{background:var(--pr);color:#fff;border-radius:9px;padding:3px 10px;font-size:.78rem}
.del{width:auto;padding:8px 13px;margin:0;font-size:.78rem;background:var(--erb);color:var(--er)}
.pair{display:flex;align-items:center;gap:8px;margin:12px 0 0}
.pair small{width:2.6em;margin:0;font-weight:700;font-size:.72rem;letter-spacing:.06em}
.pair span{font-weight:700}
.pair select{flex:1;min-width:0}
small{display:block;margin-top:12px;font-size:.77rem;line-height:1.5;color:var(--mu)}
.advbox label{display:block;margin:15px 0 6px;font-size:.78rem;font-weight:600;color:var(--mu)}
.advbox label.sw{display:flex;align-items:center;gap:11px;margin-top:16px;font-size:.9rem;font-weight:500;color:var(--tx)}
details summary{list-style:none;cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--mu)}
details summary::-webkit-details-marker{display:none}
details summary::after{content:"+";font-size:1.3rem;line-height:1}
details[open] summary::after{content:"\2212"}
.wh{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:12px}
.wh h2{margin:0}
.wb{font-size:.7rem;font-weight:700;padding:5px 11px;border-radius:999px;background:var(--ln);color:var(--mu);white-space:nowrap}
.wb.w1{background:var(--wab);color:var(--wa)}
.wb.w2{background:var(--okb);color:var(--ok)}
.wb.w3{background:var(--erb);color:var(--er)}
#msg{position:fixed;left:50%;bottom:calc(84px + env(safe-area-inset-bottom));transform:translateX(-50%);z-index:30;width:calc(100% - 32px);max-width:480px;padding:12px 16px;border-radius:14px;font-size:.88rem;font-weight:600;text-align:center;box-shadow:0 8px 28px rgba(0,0,0,.25)}
#msg:empty{display:none}
.ok{background:var(--ok);color:#fff}
.err{background:var(--er);color:#fff}
.tabs{position:fixed;left:0;right:0;bottom:0;z-index:25;display:flex;justify-content:center;gap:4px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));background:var(--card);border-top:1px solid var(--ln)}
.tabs button{flex:1;max-width:130px;margin:0;padding:8px 4px;display:flex;flex-direction:column;align-items:center;gap:3px;background:none;color:var(--mu);font-size:.68rem;font-weight:600;border-radius:12px}
.tabs button svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.tabs button.act{background:var(--prs);color:var(--pr)}
footer{text-align:center;font-size:.72rem;color:var(--mu);padding:14px 0 0}
details.gear summary{width:36px;height:36px;border-radius:10px;background:var(--in);border:1px solid var(--ln);justify-content:center;font-size:1.15rem;letter-spacing:0;color:var(--tx)}
details.gear summary::after,details.gear[open] summary::after{content:none}
.gm label,.cfg2 label{display:block;margin:10px 0 5px;font-size:.7rem;font-weight:600;color:var(--mu)}
.gm label:first-child,.cfg2 label{margin-top:0}
.cfg2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px}
.chips{display:flex;gap:8px;overflow-x:auto;padding:14px 2px 2px}
.chip{width:auto;flex:none;margin:0;padding:9px 16px;border-radius:999px;background:var(--in);color:var(--mu);border:1px solid var(--ln);font-size:.82rem;white-space:nowrap}
.chip.act{background:var(--pr);color:#fff;border-color:var(--pr)}
.sw-card{--c:#5fd13a;padding:0;background:#13221a;border-color:#1e3a5a;transition:background .25s}
.sw-card.st-off{--c:#c4281c;background:#450f0f;border-color:#5a1e1e}
.hd{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:10px 12px;background:#163a5c;border-radius:17px 17px 0 0}
.pl{display:flex;align-items:center;justify-content:center;padding:5px 12px;border-radius:999px;font-family:Georgia,"Times New Roman",serif;font-size:.72rem;font-weight:800;white-space:nowrap}
.pl.nm{flex:1 1 70px;min-width:0;display:block;overflow:hidden;text-overflow:ellipsis;background:#bcc3c9;color:#1e4a8a;font-size:1rem;font-weight:400}
.pl.p-on{background:#5fd13a;color:#10200c}
.pl.p-off{background:#c4281c;color:#2a0707}
.pl.gp{background:#1e4a8a;color:#fbbf24;border:3px solid #bcc3c9}
.hd details.gear summary{width:34px;height:34px;border:0;background:none;color:#fde7c8;font-size:1.5rem}
.pw{position:relative}
.pw input{padding-right:48px}
.pw .eye{position:absolute;right:4px;top:50%;transform:translateY(-50%);width:40px;height:40px;padding:0;margin:0;background:none;color:var(--mu);display:flex;align-items:center;justify-content:center}
.pw .eye:active{transform:translateY(-50%)}
.pw .eye svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.pw .eye .sl{display:none}
.pw .eye.on{color:var(--pr)}
.pw .eye.on .sl{display:block}
.hd details.gear[open]{flex:1 1 100%}
.hd details.gear[open] summary{margin-left:auto}
.gm{position:static;width:100%;max-width:none;margin-top:8px;background:var(--card);border:1px solid var(--ln);border-radius:14px;padding:14px}
.bd{display:flex;align-items:center;gap:16px;padding:20px 16px 26px}
.bt{position:relative;flex:1.3;height:76px;display:block;border:4px solid var(--c);border-radius:999px;background:#000;cursor:pointer;transition:border-color .2s}
.bt input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;cursor:pointer;z-index:2;border-radius:999px}
.bt i{position:absolute;top:50%;left:10px;width:52px;height:52px;border-radius:50%;background:var(--c);transform:translateY(-50%);transition:left .2s,background .2s}
.bt input:checked~i{left:calc(100% - 62px)}
.ab{flex:1;height:76px;margin:0;padding:0;border:4px solid #c4281c;border-radius:18px;background:#000;color:#c4281c;font-size:1.6rem;font-weight:400}
.ab.act{border-color:#5fd13a;color:#5fd13a}
.plus{width:34px;height:34px;margin:0;padding:0;flex:none;border-radius:50%;font-size:1.5rem;line-height:1;display:grid;place-items:center}
.plus[hidden],body:not([data-t=home]) .plus{display:none}
</style>
</head>
<body data-t="home">
<header class="top">
  <div class="logo"><svg viewBox="0 0 24 24"><path d="M9 21h6v-1H9v1zm3-19a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z"/></svg></div>
  <div class="brand"><b>LIGHT Controller</b><span>MADE BY TALHA</span></div>
  <div class="temp" id="temp">CPU --&deg;C</div>
  <button class="plus" id="addCh" onclick="addCh()" title="Add switch">+</button>
</header>
<main>

<section class="pane" data-t="home">
  <div class="card rtc-card">
    <div class="rtc-title">Current RTC Time</div>
    <div class="big" id="time">--:--</div>
  </div>

  <div id="cards"></div>
  <small>Manual override lasts until the next schedule change of that switch. Up to 12 switches (one GPIO each).</small>
</section>

<section class="pane" data-t="sched">
  <div class="page-t">Schedules</div>
  <div class="page-s">Up to 10 time windows per switch</div>
  <div class="chips" id="chips"></div>
  <div class="card">
    <div id="list"></div>
    <button class="b-add" id="addBtn" onclick="addRow([8,0,18,0,1]);renum()">+ Add schedule</button>
    <button onclick="saveSchedule()">Save Schedules</button>
    <small>The switch is ON when the time is inside any enabled schedule. Pick the switch with the tabs above.</small>
  </div>
</section>

<section class="pane" data-t="net">
  <div class="page-t">Network</div>
  <div class="page-s">Connect the controller to your router</div>
  <div class="card">
    <div class="wh"><h2>Router Wi-Fi</h2><span class="wb" id="wb">Wi-Fi: --</span></div>
    <div class="row"><span>Router</span><span id="w_cur">--</span></div>
    <div class="row"><span>IP</span><span id="w_ip">--</span></div>
    <div class="row"><span>Address</span><span>http://esplight.local/</span></div>
    <div class="advbox">
      <label>Router name (SSID)</label><input type="text" id="w_ssid" maxlength="32">
      <label>Router password (empty = open network)</label><input type="password" id="w_pass" maxlength="63">
    </div>
    <button onclick="wifiConnect()">Connect</button>
    <button class="b-off" id="w_forget" onclick="wifiForget()">Forget this router</button>
    <small>After connecting, the ESP AP channel follows the router channel, so this page may disconnect for a moment. Then join the router Wi-Fi and open http://esplight.local . The page also works through the router when the AP is OFF.</small>
  </div>
</section>

<section class="pane" data-t="set">
  <div class="page-t">Settings</div>
  <div class="page-s">Clock and advanced options</div>
  <div class="card">
    <h2>RTC time</h2>
    <button onclick="syncTime()">Sync RTC with Phone Time</button>
  </div>
  <div class="card">
    <details id="adv">
      <summary>Advanced options</summary>
      <div class="advbox">
        <label>CPU clock</label><select id="a_cpu"></select>
        <label>Wi-Fi TX power</label><select id="a_tx"></select>
        <label>Wi-Fi channel</label><select id="a_ch"></select>
        <label>Wi-Fi mode</label><select id="a_proto"></select>
        <label>Max connected phones</label><select id="a_mc"></select>
        <label>Wi-Fi AP auto-off</label><select id="a_ao"></select>
        <label>Double-click window (ms, 200-600)</label><input type="number" id="a_dbl" min="200" max="600" step="10">
        <label>Long-press time (ms, 1000-5000)</label><input type="number" id="a_lng" min="1000" max="5000" step="100">
        <label>Wi-Fi name (SSID)</label><input type="text" id="a_ssid" maxlength="32">
        <label>Wi-Fi password (8-63 chars)</label><input type="password" id="a_pass" maxlength="63" placeholder="leave blank to keep current">
        <label class="sw"><input type="checkbox" id="a_open" onchange="$('a_pass').disabled=this.checked"> Open network (no password)</label>
        <button onclick="saveAdv()">Save Advanced</button>
        <button class="b-auto" onclick="resetAdv()">Reset to defaults</button>
        <label>Change password</label>
        <input type="password" id="p_old" maxlength="32" placeholder="Old password" autocomplete="current-password">
        <input type="password" id="p_new" maxlength="32" placeholder="New password (4-32 characters)" autocomplete="new-password" style="margin-top:8px">
        <input type="password" id="p_new2" maxlength="32" placeholder="Confirm new password" autocomplete="new-password" style="margin-top:8px">
        <button onclick="changePass()">Change password</button>
        <button class="b-auto" onclick="logout()">Log out</button>
        <button class="b-off" onclick="systemReset()">System reset (erase all data)</button>
        <small>CPU, power and button timing apply at once. Channel, mode, clients, name and password restart the Wi-Fi: reconnect to the new settings afterwards. Lower TX power = shorter range. System reset erases ALL saved data (switches, names, GPIOs, schedules, overrides, router, Wi-Fi and advanced settings) and restarts the controller with factory defaults. Holding the button (long press) does the same, and the login password is erased too: the next visit asks to create a new password.</small>
      </div>
    </details>
  </div>
</section>

<footer>Firmware v14.9</footer>
</main>

<div id="msg"></div>

<nav class="tabs" id="tabs">
  <button data-t="home" class="act"><svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>Home</button>
  <button data-t="sched"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Schedules</button>
  <button data-t="net"><svg viewBox="0 0 24 24"><path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1"/></svg>Network</button>
  <button data-t="set"><svg viewBox="0 0 24 24"><path d="M4 6h8M18 6h2M4 12h2M12 12h8M4 18h10M20 18h0"/><circle cx="15" cy="6" r="2.2"/><circle cx="9" cy="12" r="2.2"/><circle cx="17" cy="18" r="2.2"/></svg>Settings</button>
</nav>

<script>
const $ = id => document.getElementById(id);
const MAXS = 10;
let busy = false, timer = null;
let CFG = null, selCh = 0, cv = -1;
let hold = 0, openNew = -1;

const pad = n => String(n).padStart(2, '0');
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function mkSel(count, val) {
  const el = document.createElement('select');
  for (let i = 0; i < count; i++) {
    const o = document.createElement('option');
    o.value = i;
    o.textContent = pad(i);
    el.appendChild(o);
  }
  el.value = val;
  return el;
}

function pair(label, h, m) {
  const d = document.createElement('div');
  d.className = 'pair';
  const l = document.createElement('small');
  l.textContent = label;
  const c = document.createElement('span');
  c.textContent = ':';
  const sh = mkSel(24, h);
  const sm = mkSel(60, m);
  sh.className = 'h'; sm.className = 'm';
  d.append(l, sh, c, sm);
  return d;
}

function showMsg(txt, isErr) {
  const m = $('msg');
  m.textContent = txt;
  m.className = isErr ? 'err' : 'ok';
  setTimeout(() => { if (m.textContent === txt) m.textContent = ''; }, 3500);
}

async function api(path, body) {
  try {
    const res = await fetch(path, body !== undefined ? { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body } : {});
    if (res.status === 401) { location.reload(); return null; }
    const j = await res.json().catch(() => null);
    if (!res.ok) throw new Error((j && j.msg) || ('HTTP ' + res.status));
    return j;
  } catch (e) {
    showMsg(e.message || 'Connection error', true);
    return null;
  }
}

let curTab = 'home', schedDirty = true, advLoaded = false;

function switchTab(t) {
  curTab = t;
  document.body.setAttribute('data-t', t);
  document.querySelectorAll('.tabs button').forEach(b => {
    b.classList.toggle('act', b.getAttribute('data-t') === t);
  });
  if (t === 'sched' && schedDirty) renderSchedTab();
  if (t === 'set' && !advLoaded) loadAdv();
}

document.querySelectorAll('.tabs button').forEach(b => {
  b.onclick = () => switchTab(b.getAttribute('data-t'));
});

async function setOvr(i, m) {
  const res = await api('/api/override', `ch=${i}&mode=${m}`);
  if (res && res.ok) showMsg(res.msg);
  pollStatus();
}

function toggleCh(i, el) {
  hold = Date.now() + 1500;
  setOvr(i, el.checked ? 1 : 2);
}

async function syncTime() {
  const d = new Date();
  const body = `y=${d.getFullYear()}&mo=${d.getMonth()+1}&d=${d.getDate()}&h=${d.getHours()}&mi=${d.getMinutes()}&s=${d.getSeconds()}`;
  const res = await api('/api/sync', body);
  if (res && res.ok) { showMsg(res.msg); pollStatus(); }
}

function addRow(s) {
  const list = $('list');
  if (list.children.length >= MAXS) return;

  const div = document.createElement('div');
  div.className = 'sch';

  const sh = document.createElement('div');
  sh.className = 'sh';

  const num = document.createElement('span');
  num.className = 'num';
  num.textContent = '#' + (list.children.length + 1);

  const lbl = document.createElement('label');
  const chk = document.createElement('input');
  chk.type = 'checkbox';
  chk.checked = !!s[4];
  chk.className = 'en';
  lbl.append(chk, document.createTextNode(' Enable window'));

  const del = document.createElement('button');
  del.className = 'del';
  del.textContent = 'Delete';
  del.onclick = () => { div.remove(); renum(); };

  sh.append(num, lbl, del);
  div.append(sh, pair('ON', s[0], s[1]), pair('OFF', s[2], s[3]));
  list.append(div);
  renum();
}

function renum() {
  const rows = $('list').querySelectorAll('.sch');
  rows.forEach((r, idx) => r.querySelector('.num').textContent = '#' + (idx + 1));
  $('addBtn').disabled = rows.length >= MAXS;
}

async function saveSchedule() {
  const rows = $('list').querySelectorAll('.sch');
  if (!rows.length) { showMsg('At least 1 schedule required', true); return; }

  const list = [];
  for (const r of rows) {
    const onH = r.querySelector('.pair:nth-child(2) .h').value;
    const onM = r.querySelector('.pair:nth-child(2) .m').value;
    const offH = r.querySelector('.pair:nth-child(3) .h').value;
    const offM = r.querySelector('.pair:nth-child(3) .m').value;
    const en = r.querySelector('.en').checked ? 1 : 0;

    if (onH === offH && onM === offM) { showMsg('ON and OFF times must differ', true); return; }
    list.push(`${onH},${onM},${offH},${offM},${en}`);
  }

  const res = await api('/api/schedule', `ch=${selCh}&sch=${encodeURIComponent(list.join(';'))}`);
  if (res && res.ok) { showMsg(res.msg); loadChannels(); }
}

function renderSchedTab() {
  if (!CFG || !CFG.chs.length) return;
  schedDirty = false;
  const chips = $('chips');
  chips.innerHTML = '';

  CFG.chs.forEach((c, idx) => {
    const btn = document.createElement('button');
    btn.className = 'chip' + (idx === selCh ? ' act' : '');
    btn.textContent = c.name;
    btn.onclick = () => { selCh = idx; schedSig = ''; renderSchedTab(); };
    chips.appendChild(btn);
  });

  const list = $('list');
  list.innerHTML = '';
  const ch = CFG.chs[selCh];
  if (ch && ch.sch) {
    ch.sch.forEach(s => addRow(s));
  }
}

async function saveCh(i) {
  const name = encodeURIComponent($(`cn_${i}`).value.trim());
  const pin = $(`cp_${i}`).value;
  const ah = $(`ca_${i}`).checked ? 1 : 0;
  const od = $(`co_${i}`).checked ? 1 : 0;

  const res = await api('/api/channel/save', `ch=${i}&name=${name}&pin=${pin}&ah=${ah}&od=${od}`);
  if (res && res.ok) { showMsg(res.msg); loadChannels(); }
}

async function addCh() {
  openNew = CFG ? CFG.chs.length : 0;
  const res = await api('/api/channel/save', `ch=${openNew}&name=Switch&pin=-1&ah=0&od=1`);
  if (res && res.ok) { showMsg(res.msg); loadChannels(); }
  else openNew = -1;
}

async function delCh(i) {
  if (!confirm('Delete this switch?')) return;
  const res = await api('/api/channel/delete', `ch=${i}`);
  if (res && res.ok) {
    showMsg(res.msg);
    if (selCh >= i && selCh > 0) selCh--;
    loadChannels();
  }
}

// Cards are built ONLY when the switch configuration changes.
function buildCards(openIdx) {
  const div = $('cards');
  div.innerHTML = '';
  if (!CFG) return;

  CFG.chs.forEach((c, i) => {
    let pinOpts = '';
    CFG.allowed.forEach(p => {
      pinOpts += `<option value="${p}" ${p === c.pin ? 'selected' : ''}>GPIO ${p}</option>`;
    });

    const card = document.createElement('div');
    card.className = 'card sw-card st-off';
    card.id = 'card_' + i;
    card.innerHTML = `
      <div class="hd">
        <div class="pl nm">${esc(c.name)}</div>
        <div class="pl p-off" id="sc_${i}">Schedule OFF</div>
        <div class="pl p-off" id="st_${i}">OFF</div>
        <div class="pl gp">GPIO ${c.pin}</div>
        <details class="gear" ${i === openIdx ? 'open' : ''}>
          <summary>&#9728;&#xFE0E;</summary>
          <div class="gm">
            <label>Name</label><input type="text" id="cn_${i}" value="${esc(c.name)}" maxlength="16">
            <label>GPIO Pin</label><select id="cp_${i}">${pinOpts}</select>
            <div class="cfg2">
              <div><label>Active Level</label><label class="sw" style="margin:0"><input type="checkbox" id="ca_${i}" ${c.ah ? 'checked' : ''}> HIGH</label></div>
              <div><label>Output Mode</label><label class="sw" style="margin:0"><input type="checkbox" id="co_${i}" ${c.od ? 'checked' : ''}> OpenDrain</label></div>
            </div>
            <button onclick="saveCh(${i})">Save Config</button>
            ${CFG.chs.length > 1 ? `<button class="b-off" onclick="delCh(${i})">Delete Switch</button>` : ''}
          </div>
        </details>
      </div>
      <div class="bd">
        <label class="bt"><input type="checkbox" id="rs_${i}" onchange="toggleCh(${i},this)"><i></i></label>
        <button class="ab" id="au_${i}" onclick="setOvr(${i},0)">Auto</button>
      </div>`;
    div.appendChild(card);
  });

  $('addCh').hidden = !(CFG.chs.length < CFG.max);
}

// Status updates only touch classes / text / toggle values (nothing is rebuilt).
function updateCards(data) {
  if (!CFG || data.chs.length !== CFG.chs.length) return;

  data.chs.forEach((c, i) => {
    const card = $('card_' + i);
    if (!card) return;

    const sc = $('sc_' + i);
    sc.textContent = 'Schedule ' + (c.son ? 'ON' : 'OFF');
    sc.className = 'pl ' + (c.son ? 'p-on' : 'p-off');

    const st = $('st_' + i);
    st.textContent = c.rel ? 'ON' : 'OFF';
    st.className = 'pl ' + (c.rel ? 'p-on' : 'p-off');

    card.classList.toggle('st-off', !c.rel);

    const rs = $('rs_' + i);
    if (Date.now() > hold && rs.checked !== c.rel) rs.checked = c.rel;

    $('au_' + i).classList.toggle('act', c.ovr === 'AUTO');
  });
}

async function pollStatus() {
  if (busy || document.hidden) return;
  busy = true;
  const data = await api('/api/status');
  busy = false;
  if (!data) return;

  if (data.cv !== cv) await loadChannels(true);

  $('time').textContent = data.rtc ? data.time.slice(0, 16) : 'RTC Failure';
  if (data.temp === undefined) $('temp').style.display = 'none';
  else {
    $('temp').textContent = 'CPU ' + data.temp + '\u00B0C';
    $('temp').className = 'temp' + (data.temp > 70 ? ' hot' : (data.temp > 55 ? ' warm' : ''));
  }

  updateCards(data);

  $('wb').textContent = 'Wi-Fi: ' + (data.sta ? 'Connected' : 'Disconnected');
  $('wb').className = 'wb ' + (data.sta ? 'w2' : 'w1');
  $('w_cur').textContent = data.ssid || 'None';
  $('w_ip').textContent = data.ip || '--';
}

let cardSig = '', schedSig = '';

async function loadChannels(fromPoll) {
  const c = await api('/api/channels');
  if (c) {
    CFG = c;
    cv = c.cv;
    if (selCh >= CFG.chs.length) selCh = 0;

    const sig = JSON.stringify(CFG.chs.map(x => [x.name, x.pin, x.ah, x.od]));
    if (sig !== cardSig || openNew >= 0) {
      cardSig = sig;
      buildCards(openNew);
    }
    openNew = -1;

    const ss = JSON.stringify(CFG.chs.map(x => [x.name, x.sch])) + '|' + selCh;
    if (ss !== schedSig) {
      schedSig = ss;
      schedDirty = true;
      if (curTab === 'sched') renderSchedTab();
    }
  }
  if (fromPoll !== true) pollStatus();
}

async function wifiConnect() {
  const s = $('w_ssid').value.trim();
  const p = $('w_pass').value.trim();
  if (!s) { showMsg('Enter SSID', true); return; }
  const res = await api('/api/wifi', `ssid=${encodeURIComponent(s)}&pass=${encodeURIComponent(p)}`);
  if (res && res.ok) showMsg(res.msg);
}

async function wifiForget() {
  if (!confirm('Forget router Wi-Fi?')) return;
  const res = await api('/api/wifi/forget', '');
  if (res && res.ok) showMsg(res.msg);
}

function initAdvForm(a) {
  const cSel = $('a_cpu'); cSel.innerHTML = '<option value="80">80 MHz</option><option value="160">160 MHz</option><option value="240">240 MHz</option>';
  cSel.value = a.cpu;

  const tSel = $('a_tx'); tSel.innerHTML = '';
  a.txs.forEach((t, i) => tSel.innerHTML += `<option value="${i}">${t} dBm</option>`);
  tSel.value = a.tx;

  const chSel = $('a_ch'); chSel.innerHTML = '';
  for (let i = 1; i <= 13; i++) chSel.innerHTML += `<option value="${i}">Channel ${i}</option>`;
  chSel.value = a.ch;

  $('a_proto').innerHTML = '<option value="0">802.11b</option><option value="1">802.11b/g</option><option value="2">802.11b/g/n</option>';
  $('a_proto').value = a.proto;

  $('a_mc').innerHTML = '<option value="1">1 Phone</option><option value="2">2 Phones</option><option value="3">3 Phones</option><option value="4">4 Phones</option>';
  $('a_mc').value = a.mc;

  $('a_ao').innerHTML = '<option value="0">Disabled</option><option value="1">Enabled (2 min idle)</option>';
  $('a_ao').value = a.ao;

  $('a_dbl').value = a.dbl;
  $('a_lng').value = a.lng;
  $('a_ssid').value = a.ssid;
  $('a_pass').value = '';
  $('a_open').checked = !a.hasPass;
  $('a_pass').disabled = !a.hasPass;
}

async function loadAdv() {
  const a = await api('/api/adv');
  if (a) { initAdvForm(a); advLoaded = true; }
}

async function saveAdv() {
  const cpu = $('a_cpu').value;
  const tx = $('a_tx').value;
  const ch = $('a_ch').value;
  const proto = $('a_proto').value;
  const mc = $('a_mc').value;
  const ao = $('a_ao').value;
  const dbl = $('a_dbl').value;
  const lng = $('a_lng').value;
  const ssid = encodeURIComponent($('a_ssid').value.trim());
  const open = $('a_open').checked ? 1 : 0;
  const pass = encodeURIComponent($('a_pass').value.trim());

  const body = `cpu=${cpu}&tx=${tx}&ch=${ch}&proto=${proto}&mc=${mc}&ao=${ao}&dbl=${dbl}&lng=${lng}&ssid=${ssid}&open=${open}&pass=${pass}`;
  const res = await api('/api/adv/save', body);
  if (res && res.ok) showMsg(res.msg);
}

async function resetAdv() {
  if (!confirm('Reset advanced options to defaults?')) return;
  const res = await api('/api/adv/reset', '');
  if (res && res.ok) { showMsg(res.msg); loadAdv(); }
}

async function changePass() {
  const o = $('p_old').value, n = $('p_new').value, n2 = $('p_new2').value;
  if (!o || !n || !n2) { showMsg('Fill in all three password boxes', true); return; }
  if (n.length < 4 || n.length > 32) { showMsg('New password: 4 to 32 characters', true); return; }
  if (n !== n2) { showMsg('New passwords do not match', true); return; }

  const res = await api('/api/auth/change', `old=${encodeURIComponent(o)}&pass=${encodeURIComponent(n)}&pass2=${encodeURIComponent(n2)}`);
  if (res && res.ok) {
    showMsg(res.msg);
    $('p_old').value = ''; $('p_new').value = ''; $('p_new2').value = '';
  }
}

async function logout() {
  await api('/api/auth/logout', '');
  location.reload();
}

const EYE = '<svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/><path class="sl" d="M3 3l18 18"/></svg>';

function addEyes() {
  document.querySelectorAll('input[type=password]').forEach(inp => {
    if (inp.parentElement.classList.contains('pw')) return;
    const wrap = document.createElement('div');
    wrap.className = 'pw';
    if (inp.style.marginTop) { wrap.style.marginTop = inp.style.marginTop; inp.style.marginTop = ''; }
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);

    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'eye';
    b.setAttribute('aria-label', 'Show password');
    b.innerHTML = EYE;
    b.onclick = () => {
      const show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      b.classList.toggle('on', show);
      b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    };
    wrap.appendChild(b);
  });
}

async function systemReset() {
  if (!confirm('SYSTEM RESET\n\nThis erases ALL saved data and restores factory defaults. Continue?')) return;
  if (!confirm('Are you sure? This cannot be undone.')) return;
  const res = await api('/api/system/reset', '');
  if (res && res.ok) showMsg(res.msg);
}

window.onload = () => {
  addEyes();
  pollStatus();
  timer = setInterval(pollStatus, 5000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) pollStatus(); });
};
</script>
</body>
</html>
)rawliteral";

// ============================================================
//  WEB SERVER HANDLERS (API)
// ============================================================

// ============================================================
//  LOGIN (single password, salted SHA-256 hash in NVS, RAM sessions)
// ============================================================

const uint8_t PW_MIN_LEN = 4;
const uint8_t PW_MAX_LEN = 32;
const uint8_t MAX_SESSIONS = 4;
const uint8_t LOGIN_MAX_FAILS = 5;
const unsigned long LOGIN_LOCK_MS = 30000UL;

bool    pwSet = false;
uint8_t pwSalt[16];
uint8_t pwHash[32];

char    sessions[MAX_SESSIONS][33];
uint8_t sessionNext = 0;

uint8_t       loginFails = 0;
bool          loginLocked = false;
unsigned long loginLockUntil = 0;

void pwCompute(const char *pass, const uint8_t *salt, uint8_t *out)
{
  size_t pl = strlen(pass);
  uint8_t h[32];
  mbedtls_sha256_context ctx;
  mbedtls_sha256_init(&ctx);

  mbedtls_sha256_starts(&ctx, 0);
  mbedtls_sha256_update(&ctx, salt, 16);
  mbedtls_sha256_update(&ctx, (const uint8_t *)pass, pl);
  mbedtls_sha256_finish(&ctx, h);

  for (uint16_t i = 1; i < 2000; i++)
  {
    mbedtls_sha256_starts(&ctx, 0);
    mbedtls_sha256_update(&ctx, h, 32);
    mbedtls_sha256_update(&ctx, salt, 16);
    mbedtls_sha256_update(&ctx, (const uint8_t *)pass, pl);
    mbedtls_sha256_finish(&ctx, h);
  }

  mbedtls_sha256_free(&ctx);
  memcpy(out, h, 32);
}

bool pwTextOk(const String &p)
{
  if (p.length() < PW_MIN_LEN || p.length() > PW_MAX_LEN) return false;
  for (size_t i = 0; i < p.length(); i++)
  {
    unsigned char c = p[i];
    if (c < 32 || c > 126) return false;
  }
  return true;
}

bool pwVerify(const char *pass)
{
  if (!pwSet) return false;
  uint8_t h[32];
  pwCompute(pass, pwSalt, h);

  uint8_t diff = 0;
  for (uint8_t i = 0; i < 32; i++) diff |= (h[i] ^ pwHash[i]);
  return diff == 0;
}

void loadPassword()
{
  pwSet = false;
  if (!preferences.begin("light_ctrl", false)) return;

  if (preferences.getBytesLength("pw_hash") == 32 && preferences.getBytesLength("pw_salt") == 16 &&
      preferences.getBytes("pw_hash", pwHash, 32) == 32 &&
      preferences.getBytes("pw_salt", pwSalt, 16) == 16)
    pwSet = true;

  preferences.end();
}

bool savePassword(const char *pass)
{
  uint8_t salt[16], hash[32];
  for (uint8_t i = 0; i < 16; i += 4)
  {
    uint32_t r = esp_random();
    memcpy(&salt[i], &r, 4);
  }
  pwCompute(pass, salt, hash);

  if (!preferences.begin("light_ctrl", false))
  {
    Serial.println("NVS open failed: password NOT persisted.");
    return false;
  }

  bool ok = (preferences.putBytes("pw_salt", salt, 16) == 16) &&
            (preferences.putBytes("pw_hash", hash, 32) == 32);
  preferences.end();

  if (!ok)
  {
    Serial.println("NVS write failed: password NOT persisted.");
    return false;
  }

  memcpy(pwSalt, salt, 16);
  memcpy(pwHash, hash, 32);
  pwSet = true;
  return true;
}

void clearSessions()
{
  memset(sessions, 0, sizeof(sessions));
  sessionNext = 0;
}

void newSession(char *out)
{
  static const char hex[] = "0123456789abcdef";
  for (uint8_t i = 0; i < 32; i += 8)
  {
    uint32_t r = esp_random();
    for (uint8_t k = 0; k < 8; k++) { out[i + k] = hex[r & 0xF]; r >>= 4; }
  }
  out[32] = '\0';

  strcpy(sessions[sessionNext], out);
  sessionNext = (sessionNext + 1) % MAX_SESSIONS;
}

bool getSid(char *out)
{
  if (!server.hasHeader("Cookie")) return false;

  String c = " " + server.header("Cookie");
  int p = c.indexOf(" sid=");
  if (p < 0) return false;

  p += 5;
  int e = c.indexOf(';', p);
  if (e < 0) e = c.length();
  if (e - p != 32) return false;

  memcpy(out, c.c_str() + p, 32);
  out[32] = '\0';
  return true;
}

bool isAuthed()
{
  if (!pwSet) return false;

  char sid[33];
  if (!getSid(sid)) return false;

  for (uint8_t i = 0; i < MAX_SESSIONS; i++)
    if (sessions[i][0] && strcmp(sessions[i], sid) == 0) return true;

  return false;
}

bool requireAuth()
{
  if (isAuthed()) return true;
  server.send(401, "application/json", "{\"ok\":false,\"auth\":false,\"msg\":\"Login required\"}");
  return false;
}

#define AUTHED(fn) ([]() { if (requireAuth()) fn(); })

void sendSessionCookie(const char *tok)
{
  server.sendHeader("Set-Cookie", String("sid=") + tok + "; Path=/; Max-Age=2592000; HttpOnly; SameSite=Strict");
}

void sendJson(int code, bool ok, const char *msg)
{
  server.send(code, "application/json",
              String("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" + msg + "\"}");
}

// Returns false (and answers 429) while the brute-force lock is active.
bool loginAllowed()
{
  if (loginLocked)
  {
    long left = (long)(loginLockUntil - millis());
    if (left > 0)
    {
      char m[48];
      snprintf(m, sizeof(m), "Too many attempts. Wait %ld s", left / 1000 + 1);
      sendJson(429, false, m);
      return false;
    }
    loginLocked = false;
    loginFails = 0;
  }
  return true;
}

void loginFailed()
{
  if (++loginFails >= LOGIN_MAX_FAILS)
  {
    loginLocked = true;
    loginLockUntil = millis() + LOGIN_LOCK_MS;
  }
}

void handleApiAuthSetup()
{
  if (pwSet) { sendJson(403, false, "Password already set"); return; }

  String p1 = server.arg("pass");
  String p2 = server.arg("pass2");

  if (!pwTextOk(p1)) { sendJson(400, false, "Password: 4 to 32 plain characters"); return; }
  if (p1 != p2)      { sendJson(400, false, "Passwords do not match"); return; }

  if (!savePassword(p1.c_str())) { sendJson(500, false, "Could not save password"); return; }

  clearSessions();
  char tok[33];
  newSession(tok);
  sendSessionCookie(tok);
  sendJson(200, true, "Password saved");
}

void handleApiAuthLogin()
{
  if (!pwSet) { sendJson(403, false, "Create a password first"); return; }
  if (!loginAllowed()) return;

  if (!pwVerify(server.arg("pass").c_str()))
  {
    loginFailed();
    sendJson(403, false, "Wrong password");
    return;
  }

  loginFails = 0;
  char tok[33];
  newSession(tok);
  sendSessionCookie(tok);
  sendJson(200, true, "Logged in");
}

void handleApiAuthLogout()
{
  char sid[33];
  if (getSid(sid))
  {
    for (uint8_t i = 0; i < MAX_SESSIONS; i++)
      if (sessions[i][0] && strcmp(sessions[i], sid) == 0) sessions[i][0] = '\0';
  }

  server.sendHeader("Set-Cookie", "sid=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict");
  sendJson(200, true, "Logged out");
}

void handleApiAuthChange()
{
  if (!loginAllowed()) return;

  String oldP = server.arg("old");
  String p1   = server.arg("pass");
  String p2   = server.arg("pass2");

  if (!pwVerify(oldP.c_str()))
  {
    loginFailed();
    sendJson(403, false, "Old password is wrong");
    return;
  }

  loginFails = 0;

  if (!pwTextOk(p1)) { sendJson(400, false, "New password: 4 to 32 plain characters"); return; }
  if (p1 != p2)      { sendJson(400, false, "New passwords do not match"); return; }

  if (!savePassword(p1.c_str())) { sendJson(500, false, "Could not save password"); return; }

  clearSessions();                       // every other phone must log in again
  char tok[33];
  newSession(tok);
  sendSessionCookie(tok);
  sendJson(200, true, "Password changed");
}

const char AUTH_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#4f46e5">
<title>LIGHT Controller</title>
<style>
:root{color-scheme:light dark;--bg:#f5f6fa;--card:#fff;--tx:#111827;--mu:#6b7280;--ln:#e5e7eb;--in:#f9fafb;--pr:#4f46e5;--er:#dc2626;--ok:#059669}
@media(prefers-color-scheme:dark){:root{--bg:#0b0f1a;--card:#141a2a;--tx:#e8eaf0;--mu:#9aa3b5;--ln:#252d42;--in:#0f1424;--pr:#818cf8;--er:#f87171;--ok:#34d399}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
[hidden]{display:none!important}
html,body{height:100%}
body{margin:0;display:flex;align-items:center;justify-content:center;padding:20px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:var(--bg);color:var(--tx);-webkit-text-size-adjust:100%}
.box{width:100%;max-width:380px;background:var(--card);border:1px solid var(--ln);border-radius:20px;padding:26px 22px;box-shadow:0 8px 28px rgba(17,24,39,.1)}
.logo{width:54px;height:54px;border-radius:16px;margin:0 auto 14px;display:flex;align-items:center;justify-content:center;background:var(--pr);color:#fff}
.logo svg{width:28px;height:28px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
h1{margin:0;text-align:center;font-size:1.3rem}
p{margin:6px 0 18px;text-align:center;font-size:.85rem;line-height:1.5;color:var(--mu)}
label{display:block;margin:14px 0 6px;font-size:.78rem;font-weight:600;color:var(--mu)}
.pw{position:relative}
input{width:100%;padding:13px 48px 13px 13px;font:inherit;font-size:1rem;border:1px solid var(--ln);border-radius:12px;background:var(--in);color:var(--tx)}
input:focus{outline:2px solid var(--pr);outline-offset:1px}
.eye{position:absolute;right:4px;top:50%;transform:translateY(-50%);width:40px;height:40px;padding:0;margin:0;border:0;border-radius:10px;background:none;color:var(--mu);cursor:pointer;display:flex;align-items:center;justify-content:center}
.eye svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.eye .sl{display:none}
.eye.on{color:var(--pr)}
.eye.on .sl{display:block}
#go{width:100%;margin-top:20px;padding:14px;font:inherit;font-size:1rem;font-weight:600;border:0;border-radius:12px;background:var(--pr);color:#fff;cursor:pointer}
#go:disabled{opacity:.5;cursor:not-allowed}
#m{margin-top:14px;min-height:1.2em;text-align:center;font-size:.85rem;font-weight:600;color:var(--er)}
</style>
</head>
<body>
<main class="box">
  <div class="logo"><svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/></svg></div>
  <h1 id="t"></h1>
  <p id="s"></p>
  <label for="p1" id="l1">Password</label>
  <div class="pw"><input type="password" id="p1" maxlength="32" autocapitalize="off" autocorrect="off" spellcheck="false"><button type="button" class="eye" aria-label="Show password"><svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/><path class="sl" d="M3 3l18 18"/></svg></button></div>
  <div id="r2">
    <label for="p2">Confirm password</label>
    <div class="pw"><input type="password" id="p2" maxlength="32" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="new-password"><button type="button" class="eye" aria-label="Show password"><svg viewBox="0 0 24 24"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/><path class="sl" d="M3 3l18 18"/></svg></button></div>
  </div>
  <button id="go"></button>
  <div id="m"></div>
</main>
<script>
const MODE = '%MODE%';
const setup = MODE === 'setup';
const $ = id => document.getElementById(id);

$('t').textContent = setup ? 'Create password' : 'Login';
$('s').textContent = setup ? 'First start: choose a password for this controller (4 to 32 characters), then type it again to confirm.' : 'Enter your password to open the controller.';
$('l1').textContent = setup ? 'New password' : 'Password';
$('go').textContent = setup ? 'Save password' : 'Login';
$('r2').hidden = !setup;
$('p1').autocomplete = setup ? 'new-password' : 'current-password';

document.querySelectorAll('.eye').forEach(b => {
  b.onclick = () => {
    const i = b.previousElementSibling;
    const show = i.type === 'password';
    i.type = show ? 'text' : 'password';
    b.classList.toggle('on', show);
    b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  };
});

function err(t) { $('m').textContent = t; }

async function go() {
  err('');
  const p1 = $('p1').value, p2 = $('p2').value;

  if (setup) {
    if (p1.length < 4 || p1.length > 32) { err('Password must be 4 to 32 characters'); return; }
    if (p1 !== p2) { err('Passwords do not match'); return; }
  } else if (!p1) { err('Enter the password'); return; }

  $('go').disabled = true;
  try {
    const body = setup ? `pass=${encodeURIComponent(p1)}&pass2=${encodeURIComponent(p2)}` : `pass=${encodeURIComponent(p1)}`;
    const res = await fetch(setup ? '/api/auth/setup' : '/api/auth/login', {
      method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body
    });
    const j = await res.json().catch(() => null);
    if (res.ok && j && j.ok) { location.reload(); return; }
    err((j && j.msg) || ('Error ' + res.status));
  } catch (e) { err('Connection error'); }
  $('go').disabled = false;
}

$('go').onclick = go;
document.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); }));
$('p1').focus();
</script>
</body>
</html>
)rawliteral";

void handleRoot()
{
  server.sendHeader("Cache-Control", "no-store");

  if (pwSet && isAuthed())
  {
    server.send(200, "text/html", INDEX_HTML);
    return;
  }

  String page = FPSTR(AUTH_HTML);
  page.replace("%MODE%", pwSet ? "login" : "setup");
  server.send(200, "text/html", page);
}

void handleApiStatus()
{
  bool sta = (WiFi.status() == WL_CONNECTED);

  String json;
  json.reserve(160 + chCount * 40);

  json = "{\"rtc\":";
  json += rtcAvailable ? "true" : "false";

  if (rtcAvailable)
  {
    char buf[24];
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d",
             currentTime.year(), currentTime.month(), currentTime.day(),
             currentTime.hour(), currentTime.minute());
    json += ",\"time\":\""; json += buf; json += "\"";
  }
  else json += ",\"time\":\"--\"";

#if ENABLE_CPU_TEMP
  json += ",\"temp\":"; json += String((int)temperatureRead());
#endif
  json += ",\"cv\":";   json += String(cfgVersion);
  json += ",\"sta\":";  json += sta ? "true" : "false";
  json += ",\"ssid\":\""; json += staSsid; json += "\"";
  json += ",\"ip\":\"";   if (sta) json += WiFi.localIP().toString(); json += "\"";

  json += ",\"chs\":[";
  for (uint8_t i = 0; i < chCount; i++)
  {
    if (i > 0) json += ",";
    json += "{\"son\":"; json += chs[i].schedOn ? "true" : "false";
    json += ",\"rel\":"; json += chs[i].relay   ? "true" : "false";
    json += ",\"ovr\":\""; json += overrideName(chs[i].ovr); json += "\"}";
  }
  json += "]}";

  server.send(200, "application/json", json);
}

void handleApiChannels()
{
  String json = "{";
  json += "\"cv\":" + String(cfgVersion) + ",";
  json += "\"max\":" + String(MAX_CH) + ",";
  json += "\"allowed\":[";
  for (uint8_t i = 0; i < MAX_CH; i++)
  {
    if (i > 0) json += ",";
    json += String(ALLOWED_PINS[i]);
  }
  json += "],\"chs\":[";

  for (uint8_t i = 0; i < chCount; i++)
  {
    if (i > 0) json += ",";
    json += "{";
    json += "\"name\":\"" + String(chs[i].name) + "\",";
    json += "\"pin\":" + String(chs[i].pin) + ",";
    json += "\"ah\":" + String(chs[i].activeHigh) + ",";
    json += "\"od\":" + String(chs[i].openDrain) + ",";
    json += "\"sch\":[";

    for (uint8_t k = 0; k < chs[i].schCount; k++)
    {
      if (k > 0) json += ",";
      json += "[" + String(chs[i].sch[k].onH) + "," +
                    String(chs[i].sch[k].onM) + "," +
                    String(chs[i].sch[k].offH) + "," +
                    String(chs[i].sch[k].offM) + "," +
                    String(chs[i].sch[k].enabled) + "]";
    }
    json += "]}";
  }
  json += "]}";

  server.send(200, "application/json", json);
}

void handleApiOverride()
{
  if (!server.hasArg("ch") || !server.hasArg("mode"))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Missing args\"}");
    return;
  }

  int ch = server.arg("ch").toInt();
  int mode = server.arg("mode").toInt();

  if (ch < 0 || ch >= chCount || mode < 0 || mode > 2)
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Invalid channel or mode\"}");
    return;
  }

  const char *msg = "";
  bool ok = applyManualOverride(ch, (OverrideMode)mode, &msg);

  server.send(200, "application/json", String("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" + msg + "\"}");
}

void handleApiSync()
{
  if (!server.hasArg("y") || !server.hasArg("mo") || !server.hasArg("d") ||
      !server.hasArg("h") || !server.hasArg("mi") || !server.hasArg("s"))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Missing time args\"}");
    return;
  }

  int y  = server.arg("y").toInt();
  int mo = server.arg("mo").toInt();
  int d  = server.arg("d").toInt();
  int h  = server.arg("h").toInt();
  int mi = server.arg("mi").toInt();
  int s  = server.arg("s").toInt();

  const char *msg = "";
  bool ok = syncRTC(y, mo, d, h, mi, s, &msg);

  server.send(200, "application/json", String("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" + msg + "\"}");
}

void handleApiSchedule()
{
  if (!server.hasArg("ch") || !server.hasArg("sch"))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Missing args\"}");
    return;
  }

  int ch = server.arg("ch").toInt();
  if (ch < 0 || ch >= chCount)
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Invalid switch\"}");
    return;
  }

  String raw = server.arg("sch");
  ScheduleSlot slots[MAX_SCHEDULES];
  uint8_t count = 0;

  int start = 0;
  while (start < raw.length() && count < MAX_SCHEDULES)
  {
    int end = raw.indexOf(';', start);
    if (end < 0) end = raw.length();

    String item = raw.substring(start, end);
    start = end + 1;

    int p0 = item.indexOf(',');
    int p1 = item.indexOf(',', p0 + 1);
    int p2 = item.indexOf(',', p1 + 1);
    int p3 = item.indexOf(',', p2 + 1);

    if (p0 < 0 || p1 < 0 || p2 < 0 || p3 < 0) continue;

    slots[count].onH     = item.substring(0, p0).toInt();
    slots[count].onM     = item.substring(p0 + 1, p1).toInt();
    slots[count].offH    = item.substring(p1 + 1, p2).toInt();
    slots[count].offM    = item.substring(p2 + 1, p3).toInt();
    slots[count].enabled = item.substring(p3 + 1).toInt();
    count++;
  }

  const char *msg = "";
  bool ok = setSchedules(ch, slots, count, &msg);

  server.send(200, "application/json", String("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" + msg + "\"}");
}

void handleApiChannelSave()
{
  if (!server.hasArg("ch") || !server.hasArg("name") || !server.hasArg("pin") ||
      !server.hasArg("ah") || !server.hasArg("od"))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Missing args\"}");
    return;
  }

  int ch = server.arg("ch").toInt();
  String nameStr = server.arg("name");
  int pin = server.arg("pin").toInt();
  uint8_t ah = server.arg("ah").toInt() ? 1 : 0;
  uint8_t od = server.arg("od").toInt() ? 1 : 0;

  if (ch < 0 || ch > chCount || ch >= MAX_CH)
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Invalid switch index\"}");
    return;
  }

  if (pin == -1)
  {
    for (uint8_t i = 0; i < MAX_CH; i++)
    {
      if (!pinUsedByChannel(ALLOWED_PINS[i], -1)) { pin = ALLOWED_PINS[i]; break; }
    }
  }

  if (!pinAllowed(pin))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Disallowed GPIO pin\"}");
    return;
  }

  if (pinUsedByChannel(pin, ch))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"GPIO pin already in use\"}");
    return;
  }

  if (!nameOk(nameStr.c_str()))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Invalid name (1-16 plain chars)\"}");
    return;
  }

  bool isNew = (ch == chCount);

  if (isNew)
  {
    chCount++;
    memset(&chs[ch], 0, sizeof(chs[ch]));
    useDefaultSchedule(chs[ch]);
  }

  bool hwChanged = isNew || chs[ch].pin != pin || chs[ch].activeHigh != ah || chs[ch].openDrain != od;
  bool nameChanged = isNew || strcmp(chs[ch].name, nameStr.c_str()) != 0;

  if (!hwChanged && !nameChanged)
  {
    server.send(200, "application/json", "{\"ok\":true,\"msg\":\"No changes\"}");
    return;
  }

  if (hwChanged && !isNew) setChannelRelay(ch, false);      // old pin to OFF level first

  chs[ch].pin = pin;
  chs[ch].activeHigh = ah;
  chs[ch].openDrain = od;
  strncpy(chs[ch].name, nameStr.c_str(), sizeof(chs[ch].name) - 1);
  chs[ch].name[sizeof(chs[ch].name) - 1] = '\0';

  if (hwChanged)
  {
    channelPinInit(chs[ch]);
    if (rtcAvailable)
    {
      chs[ch].schedOn = isScheduleON(chs[ch], currentTime);
      if (isNew) makePeriodID(chs[ch], currentTime, chs[ch].period, sizeof(chs[ch].period));
      applyChannelState(ch);
    }
  }

  bool ok = saveChannelConfig();
  if (isNew) ok = saveSchedule(ch) && ok;
  cfgVersion++;

  server.send(200, "application/json", String("{\"ok\":") + (ok ? "true" : "false") +
              ",\"msg\":\"" + (ok ? "Switch configuration saved" : "Saved but NVS write FAILED") + "\"}");
}

void handleApiChannelDelete()
{
  if (!server.hasArg("ch"))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Missing channel\"}");
    return;
  }

  int ch = server.arg("ch").toInt();

  if (ch < 0 || ch >= chCount || chCount <= 1)
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Cannot delete switch\"}");
    return;
  }

  setChannelRelay(ch, false);

  uint8_t lastIdx = chCount - 1;
  for (uint8_t i = ch; i < lastIdx; i++) chs[i] = chs[i + 1];
  memset(&chs[lastIdx], 0, sizeof(chs[lastIdx]));
  chCount--;

  // NVS keys (sch/m/p) are index based: rewrite everything that moved up,
  // then drop the keys of the now unused last index.
  for (uint8_t i = ch; i < chCount; i++)
  {
    saveSchedule(i);
    if (chs[i].ovr != AUTO_MODE) saveOverride(i);
    else                         eraseStoredOverride(i);
  }
  removeChannelKeys(lastIdx);
  if (ch == lastIdx) removeChannelKeys(ch);

  saveChannelConfig();
  cfgVersion++;

  server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Switch deleted\"}");
}

void handleApiWifi()
{
  if (!server.hasArg("ssid"))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Missing SSID\"}");
    return;
  }

  String s = server.arg("ssid");
  String p = server.hasArg("pass") ? server.arg("pass") : "";

  if (!staSsidOk(s))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Invalid SSID\"}");
    return;
  }

  if (p.length() > 0 && (p.length() < 8 || p.length() > 63))
  {
    server.send(400, "application/json", "{\"ok\":false,\"msg\":\"Password must be 8-63 chars\"}");
    return;
  }

  staSsid = s; staPass = p; staWanted = true;
  saveSta(s, p);
  staConnectRequested = true;

  server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Connecting to router...\"}");
}

void handleApiWifiForget()
{
  forgetSta();
  staSsid = ""; staPass = ""; staWanted = false;
  staForgetRequested = true;

  server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Router forgotten\"}");
}

void handleApiAdv()
{
  String json = "{";
  json += "\"cpu\":" + String(adv.cpuMhz) + ",";
  json += "\"tx\":" + String(adv.txIdx) + ",";
  json += "\"txs\":[";
  for (uint8_t i = 0; i < TX_LEVEL_COUNT; i++)
  {
    if (i > 0) json += ",";
    json += TX_DBM_TEXT[i];
  }
  json += "],";
  json += "\"ch\":" + String(adv.channel) + ",";
  json += "\"proto\":" + String(adv.proto) + ",";
  json += "\"mc\":" + String(adv.maxClients) + ",";
  json += "\"ao\":" + String(adv.autoOff) + ",";
  json += "\"dbl\":" + String(adv.dblMs) + ",";
  json += "\"lng\":" + String(adv.longMs) + ",";
  json += "\"ssid\":\"" + String(adv.ssid) + "\",";
  json += "\"hasPass\":" + String(adv.pass[0] != '\0' ? "true" : "false");
  json += "}";

  server.send(200, "application/json", json);
}

void handleApiAdvSave()
{
  AdvSettings a = adv;

  if (server.hasArg("cpu"))   a.cpuMhz     = server.arg("cpu").toInt();
  if (server.hasArg("tx"))    a.txIdx      = server.arg("tx").toInt();
  if (server.hasArg("ch"))    a.channel    = server.arg("ch").toInt();
  if (server.hasArg("proto")) a.proto      = server.arg("proto").toInt();
  if (server.hasArg("mc"))    a.maxClients = server.arg("mc").toInt();
  if (server.hasArg("ao"))    a.autoOff    = server.arg("ao").toInt();
  if (server.hasArg("dbl"))   a.dblMs      = server.arg("dbl").toInt();
  if (server.hasArg("lng"))   a.longMs     = server.arg("lng").toInt();

  if (server.hasArg("ssid"))
  {
    strncpy(a.ssid, server.arg("ssid").c_str(), sizeof(a.ssid) - 1);
    a.ssid[sizeof(a.ssid) - 1] = '\0';
  }

  if (server.hasArg("open") && server.arg("open").toInt() == 1)
  {
    a.pass[0] = '\0';
  }
  else if (server.hasArg("pass") && server.arg("pass").length() > 0)
  {
    strncpy(a.pass, server.arg("pass").c_str(), sizeof(a.pass) - 1);
    a.pass[sizeof(a.pass) - 1] = '\0';
  }

  const char *msg = "";
  if (!advValidate(a, &msg))
  {
    server.send(400, "application/json", String("{\"ok\":false,\"msg\":\"") + msg + "\"}");
    return;
  }

  bool wifiChanged = (adv.channel != a.channel || adv.proto != a.proto ||
                      adv.maxClients != a.maxClients || strcmp(adv.ssid, a.ssid) != 0 ||
                      strcmp(adv.pass, a.pass) != 0);

  if (memcmp(&adv, &a, sizeof(a)) == 0)
  {
    server.send(200, "application/json", "{\"ok\":true,\"msg\":\"No changes\"}");
    return;
  }

  bool txChanged  = (adv.txIdx != a.txIdx);
  bool cpuChanged = (adv.cpuMhz != a.cpuMhz);

  adv = a;
  applyAdvTiming();
  saveAdv();

  if (wifiChanged)
  {
    advApplyPending = true;
    advRestartAp    = true;
  }
  else
  {
    if (txChanged)  WiFi.setTxPower(TX_LEVELS[adv.txIdx]);
    if (cpuChanged) setCpuFrequencyMhz(adv.cpuMhz);
  }

  server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Advanced settings saved\"}");
}

void handleApiAdvReset()
{
  if (advIsDefault())
  {
    server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Already at defaults\"}");
    return;
  }

  advDefaults(adv);
  applyAdvTiming();
  saveAdv();

  advApplyPending = true;
  advRestartAp    = true;

  server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Advanced settings reset to defaults\"}");
}

void handleApiSystemReset()
{
  server.send(200, "application/json",
              "{\"ok\":true,\"msg\":\"Resetting... reconnect to Wi-Fi LIGHT in ~10 s\"}");
  factoryResetRequested = true;
}

void setupWebServer()
{
  static const char *hdrs[] = { "Cookie" };
  server.collectHeaders(hdrs, 1);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/auth/setup",  HTTP_POST, handleApiAuthSetup);
  server.on("/api/auth/login",  HTTP_POST, handleApiAuthLogin);
  server.on("/api/auth/logout", HTTP_POST, handleApiAuthLogout);
  server.on("/api/auth/change", HTTP_POST, AUTHED(handleApiAuthChange));
  server.on("/api/status", HTTP_GET, AUTHED(handleApiStatus));
  server.on("/api/channels", HTTP_GET, AUTHED(handleApiChannels));
  server.on("/api/override", HTTP_POST, AUTHED(handleApiOverride));
  server.on("/api/sync", HTTP_POST, AUTHED(handleApiSync));
  server.on("/api/schedule", HTTP_POST, AUTHED(handleApiSchedule));
  server.on("/api/channel/save", HTTP_POST, AUTHED(handleApiChannelSave));
  server.on("/api/channel/delete", HTTP_POST, AUTHED(handleApiChannelDelete));
  server.on("/api/wifi", HTTP_POST, AUTHED(handleApiWifi));
  server.on("/api/wifi/forget", HTTP_POST, AUTHED(handleApiWifiForget));
  server.on("/api/adv", HTTP_GET, AUTHED(handleApiAdv));
  server.on("/api/adv/save", HTTP_POST, AUTHED(handleApiAdvSave));
  server.on("/api/adv/reset", HTTP_POST, AUTHED(handleApiAdvReset));
  server.on("/api/system/reset", HTTP_POST, AUTHED(handleApiSystemReset));

  server.onNotFound([]() {
    server.send(404, "text/plain", "404 Not Found");
  });
}

// ============================================================
//  Wi-Fi AP MANAGEMENT
// ============================================================

void startAP()
{
  WiFi.persistent(false);
  WiFi.mode(staWanted ? WIFI_AP_STA : WIFI_AP);
  WiFi.softAPConfig(AP_IP, AP_GATEWAY, AP_SUBNET);

  wifi_phy_mode_t ph = (adv.proto == 0) ? WIFI_PHY_MODE_11B :
                       (adv.proto == 1) ? WIFI_PHY_MODE_11G : WIFI_PHY_MODE_11G;
  esp_wifi_set_protocol(WIFI_IF_AP, ph);

  WiFi.softAP(adv.ssid, adv.pass[0] ? adv.pass : NULL, adv.channel, 0, adv.maxClients);
  WiFi.setTxPower(TX_LEVELS[adv.txIdx]);
  wifiLowLatency();

  apEnabled = true;
  lastApClientSeen = millis();

  startServerIfNeeded();
  startMdns();

  Serial.printf("Wi-Fi AP started: SSID \"%s\", IP: %s\n", adv.ssid, AP_IP.toString().c_str());
}

void stopAP()
{
  apEnabled = false;
  WiFi.softAPdisconnect(true);

  if (!staWanted || WiFi.status() != WL_CONNECTED)
  {
    stopMdns();
    server.stop();
    serverRunning = false;
  }

  WiFi.mode(wifiIdleMode());
  Serial.println("Wi-Fi AP stopped.");
}

void applyAdvRequests()
{
  if (!advApplyPending) return;
  advApplyPending = false;

  uint16_t cpu = adv.cpuMhz < MIN_CPU_MHZ ? MIN_CPU_MHZ : adv.cpuMhz;
  if (getCpuFrequencyMhz() != cpu) setCpuFrequencyMhz(cpu);
  WiFi.setTxPower(TX_LEVELS[adv.txIdx]);

  if (advRestartAp && apEnabled)
  {
    advRestartAp = false;
    Serial.println("Restarting Wi-Fi AP with new settings...");
    startAP();
  }
}

void checkApIdleAutoOff()
{
  if (!apEnabled || adv.autoOff == 0) return;

  if (millis() - lastApCheck < AP_CHECK_INTERVAL) return;
  lastApCheck = millis();

  if (WiFi.softAPgetStationNum() > 0)
  {
    lastApClientSeen = millis();
  }
  else if (millis() - lastApClientSeen >= AP_IDLE_TIMEOUT_MS)
  {
    Serial.println("AP idle timeout (no clients connected for 2 minutes) -> Auto OFF");
    saveApState(false);
    stopAP();
  }
}

// ============================================================
//  SYSTEM (FACTORY) RESET: erase the whole NVS, then restart
// ============================================================

void doFactoryReset()
{
  Serial.println();
  Serial.println("===== SYSTEM RESET: erasing all saved data =====");

  // loads OFF first (safe state)
  setRelay(false);

  // let the HTTP response reach the phone
  unsigned long t0 = millis();
  while (millis() - t0 < 600) { server.handleClient(); delay(5); }

  preferences.end();
  nvs_flash_deinit();
  esp_err_t e = nvs_flash_erase();

  if (e == ESP_OK) Serial.println("NVS erased. Factory defaults will be used.");
  else Serial.printf("NVS erase FAILED (error %d).\n", (int)e);

  Serial.println("Restarting...");
  delay(300);
  ESP.restart();
  while (true) { delay(1000); }
}

// ============================================================
//  SETUP & LOOP
// ============================================================

void setup()
{
  initializeRelaySafely();

  Serial.begin(115200);
  delay(500);

  Serial.println("\n\n============================================================");
  Serial.println(" ESP32 Multi-Switch Controller v14.11 starting...");
  Serial.println("============================================================");

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  loadAdv();
  setCpuFrequencyMhz(adv.cpuMhz < MIN_CPU_MHZ ? MIN_CPU_MHZ : adv.cpuMhz);

  loadChannels();
  initAllChannelPins();

  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(100000);

  DateTime initialTime;
  const char *reason = "";

  if (!initializeRTC(initialTime, &reason))
  {
    markRTCFailed(reason);
  }
  else
  {
    startWithTrustedTime(initialTime);
  }

  loadPassword();
  loadSta();
  setupWebServer();

  bool wantedAp = loadApState();
  if (wantedAp) startAP();
  else          WiFi.mode(wifiIdleMode());

  if (staWanted) beginStaConnect();

  if (advLoadNote) Serial.println(advLoadNote);
  Serial.println(pwSet ? "Web login: password set." : "Web login: NO password yet - first visitor will be asked to create one.");
  printStatus();
}

void loop()
{
  checkButton();
  handleSerialCommands();

  if (wifiToggleRequested)
  {
    wifiToggleRequested = false;
    bool newState = !apEnabled;
    saveApState(newState);

    if (newState) startAP();
    else          stopAP();
  }

  if (factoryResetRequested) doFactoryReset();

  applyAdvRequests();
  checkApIdleAutoOff();

  applyStaRequests();
  staService();

  if (serverRunning) server.handleClient();

  updateRTC();
  tryRecoverRTC();

  delay(LOOP_DELAY_MS);
}
