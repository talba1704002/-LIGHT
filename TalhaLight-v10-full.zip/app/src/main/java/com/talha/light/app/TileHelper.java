package com.talha.light.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.service.quicksettings.TileService;

import java.util.HashSet;
import java.util.Set;

/**
 * Quick Settings (notification shade) tiles.
 *
 * Android needs every tile declared in the manifest, so the app ships a pool of SLOTS tiles.
 * Only as many tiles as there are switches on the controller are ENABLED, so the tile editor
 * lists exactly one tile per switch. Each slot remembers the GPIO pin it controls:
 *  - a new switch automatically takes the first free slot,
 *  - a deleted switch frees its slot,
 *  - existing slots keep their switch (nothing shifts around).
 */
final class TileHelper {

    static final int SLOTS = 16;

    private TileHelper() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(ControllerClient.PREFS, Context.MODE_PRIVATE);
    }

    static ComponentName component(Context ctx, int slot) {
        return new ComponentName(ctx.getPackageName(),
                "com.talha.light.app.SwitchTileService$Slot" + slot);
    }

    static int pinOf(Context ctx, int slot) {
        return prefs(ctx).getInt("t_pin_" + slot, -1);
    }

    /** Match slots to the controller's switches and enable/disable the tiles. Call with a good snapshot only. */
    static synchronized void sync(Context ctx, WidgetHelper.Snap s) {
        if (s == null || s.error != WidgetHelper.ERR_NONE) return;   // offline: change nothing
        SharedPreferences p = prefs(ctx);
        SharedPreferences.Editor e = p.edit();

        Set<Integer> pins = new HashSet<>();
        for (WidgetHelper.Ch c : s.chs) pins.add(c.pin);

        int[] slotPin = new int[SLOTS + 1];
        Set<Integer> used = new HashSet<>();
        for (int i = 1; i <= SLOTS; i++) {
            int pin = p.getInt("t_pin_" + i, -1);
            if (pin >= 0 && pins.contains(pin) && !used.contains(pin)) {
                slotPin[i] = pin;
                used.add(pin);
            } else {
                slotPin[i] = -1;
            }
        }
        for (WidgetHelper.Ch c : s.chs) {
            if (used.contains(c.pin)) continue;
            for (int i = 1; i <= SLOTS; i++) {
                if (slotPin[i] < 0) { slotPin[i] = c.pin; used.add(c.pin); break; }
            }
        }

        PackageManager pm = ctx.getPackageManager();
        for (int i = 1; i <= SLOTS; i++) {
            if (slotPin[i] >= 0) e.putInt("t_pin_" + i, slotPin[i]); else e.remove("t_pin_" + i);
            for (WidgetHelper.Ch c : s.chs) {
                if (c.pin == slotPin[i]) {
                    e.putString("t_name_" + i, WidgetHelper.label(c)).putBoolean("t_on_" + i, c.on);
                }
            }
            boolean enable = slotPin[i] >= 0;
            ComponentName cn = component(ctx, i);
            int want = enable ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                              : PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
            try {
                if (pm.getComponentEnabledSetting(cn) != want)
                    pm.setComponentEnabledSetting(cn, want, PackageManager.DONT_KILL_APP);
            } catch (Exception ignored) { }
        }
        e.apply();
    }

    /** Ask Android to redraw every tile that is currently added to the panel. */
    static void requestRedraw(Context ctx) {
        for (int i = 1; i <= SLOTS; i++) {
            try { TileService.requestListeningState(ctx, component(ctx, i)); } catch (Exception ignored) { }
        }
    }

    /** One network read: sync tiles with the controller, redraw cached state. */
    static void syncFromController(Context ctx) {
        sync(ctx, WidgetHelper.fetch(ctx));
        requestRedraw(ctx);
    }

}
