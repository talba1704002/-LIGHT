package com.talha.light.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Shown when a widget is placed: pick which GPIO switch this widget controls. */
public class WidgetConfigActivity extends Activity {

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView status;
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0B0D);
        root.setPadding(dp(20), dp(28), dp(20), dp(12));

        TextView title = new TextView(this);
        title.setText("Choose a switch");
        title.setTextColor(0xFFF5F5F7);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(0xFF8D8D97);
        status.setTextSize(14);
        status.setPadding(0, dp(6), 0, dp(14));
        root.addView(status);

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        load();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void load() {
        status.setText("Looking for the controller…");
        list.removeAllViews();
        final android.content.Context app = getApplicationContext();
        new Thread(() -> {
            final WidgetHelper.Snap s = WidgetHelper.fetch(app);
            ui.post(() -> { if (!isFinishing()) show(s); });
        }).start();
    }

    private void show(WidgetHelper.Snap s) {
        list.removeAllViews();
        if (s.error != WidgetHelper.ERR_NONE) {
            if (s.error == WidgetHelper.ERR_AUTH)
                status.setText("The controller needs your password. Open the LIGHT app, log in once, then come back.");
            else if (s.error == WidgetHelper.ERR_OFFLINE)
                status.setText("Cannot reach the controller. Connect to its Wi-Fi network and try again.");
            else
                status.setText("The controller answered with an unexpected reply.");
            list.addView(pill("Try again", "", true, v -> load()));
            if (s.error == WidgetHelper.ERR_AUTH) {
                list.addView(pill("Open LIGHT app", "", false, v -> {
                    Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
                    if (open != null) startActivity(open);
                }));
            }
            return;
        }
        if (s.chs.isEmpty()) {
            status.setText("The controller has no switches yet. Add one in the app first.");
            return;
        }
        status.setText("This widget will control the switch you tap:");
        for (final WidgetHelper.Ch c : s.chs) {
            String sub = "GPIO " + c.pin + "  ·  " + (c.on ? "ON" : "OFF");
            list.addView(pill(WidgetHelper.label(c), sub, false, v -> choose(c)));
        }
    }

    private void choose(WidgetHelper.Ch c) {
        SharedPreferences p = getSharedPreferences(ControllerClient.PREFS, MODE_PRIVATE);
        p.edit().putInt("w_pin_" + widgetId, c.pin)
                .putString("w_name_" + widgetId, WidgetHelper.label(c))
                .putBoolean("w_on_" + widgetId, c.on)
                .apply();
        WidgetHelper.render(this, widgetId, c.on ? WidgetHelper.ON : WidgetHelper.OFF);
        setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        finish();
    }

    private View pill(String text, String sub, boolean primary, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), dp(14), dp(18), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(primary ? 0xFFE34848 : 0xFF1B1B20);
        bg.setStroke(dp(1), primary ? 0xFFE34848 : 0xFF2A2A31);
        row.setBackground(bg);
        row.setClickable(true);
        row.setOnClickListener(l);

        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFF5F5F7);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(t);
        if (sub.length() > 0) {
            TextView s2 = new TextView(this);
            s2.setText(sub);
            s2.setTextColor(0xFF8D8D97);
            s2.setTextSize(13);
            row.addView(s2);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        row.setLayoutParams(lp);
        return row;
    }
}
