package com.talha.light.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** Home-screen hexagon switch. One widget = one GPIO switch of the controller. */
public class HexWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) WidgetHelper.renderCached(context, id);   // instant

        final PendingResult pr = goAsync();
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            try { WidgetHelper.refreshAll(app); } finally { pr.finish(); }
        }).start();
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        WidgetHelper.forget(context, ids);
    }
}
