package com.talha.light.app;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives the tap on a widget (not exported - only the widget's own PendingIntent can reach it). */
public class WidgetToggleReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!WidgetHelper.ACTION_TOGGLE.equals(intent.getAction())) return;
        final int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return;

        final PendingResult pr = goAsync();
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            try { WidgetHelper.toggle(app, id); } finally { pr.finish(); }
        }).start();
    }
}
