package com.talha.light.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.widget.RemoteViews;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Everything the home-screen hexagon widget needs: fetch state, draw, toggle. */
final class WidgetHelper {

    static final String ACTION_TOGGLE = "com.talha.light.app.WIDGET_TOGGLE";

    // widget look
    static final int ON = 0, OFF = 1, BUSY = 2, OFFLINE = 3, LOGIN = 4, MISSING = 5;
    // fetch result
    static final int ERR_NONE = 0, ERR_OFFLINE = 1, ERR_AUTH = 2, ERR_OTHER = 3;

    static final class Ch {
        int idx, pin;
        String name = "";
        boolean on;
    }

    static final class Snap {
        final List<Ch> chs = new ArrayList<>();
        int error = ERR_NONE;
    }

    private WidgetHelper() { }

    static String label(Ch c) {
        return (c.name != null && c.name.length() > 0) ? c.name : "GPIO" + c.pin;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(ControllerClient.PREFS, Context.MODE_PRIVATE);
    }

    private static int errOf(int status) {
        if (status == 0) return ERR_OFFLINE;
        if (status == 401 || status == 403) return ERR_AUTH;
        return ERR_OTHER;
    }

    // ---------- talk to the controller ----------

    static Snap fetch(Context ctx) {
        Snap s = new Snap();
        ControllerClient cl = new ControllerClient(ctx);
        ControllerClient.Res st = cl.req("GET", "/api/status", null);
        if (st.status != 200) { s.error = errOf(st.status); return s; }
        ControllerClient.Res cf = cl.req("GET", "/api/channels", null);
        if (cf.status != 200) { s.error = errOf(cf.status); return s; }
        try {
            JSONArray sa = new JSONObject(st.text).getJSONArray("chs");
            JSONArray ca = new JSONObject(cf.text).getJSONArray("chs");
            int n = Math.min(sa.length(), ca.length());
            for (int i = 0; i < n; i++) {
                JSONObject c = ca.getJSONObject(i);
                Ch ch = new Ch();
                ch.idx = i;
                ch.pin = c.getInt("pin");
                ch.name = c.optString("name", "");
                ch.on = sa.getJSONObject(i).optBoolean("rel", false);
                s.chs.add(ch);
            }
        } catch (Exception e) {
            s.error = ERR_OTHER;
        }
        return s;
    }

    private static Ch find(Snap s, int pin) {
        for (Ch c : s.chs) if (c.pin == pin) return c;
        return null;
    }

    private static int[] widgetIds(Context ctx) {
        return AppWidgetManager.getInstance(ctx)
                .getAppWidgetIds(new ComponentName(ctx, HexWidgetProvider.class));
    }

    /** Re-read the controller once and redraw every placed widget. */
    static void refreshAll(Context ctx) {
        int[] ids = widgetIds(ctx);
        SharedPreferences p = prefs(ctx);
        boolean any = false;
        for (int id : ids) if (p.getInt("w_pin_" + id, -1) >= 0) any = true;
        if (!any) return;
        Snap s = fetch(ctx);
        for (int id : ids) if (p.getInt("w_pin_" + id, -1) >= 0) apply(ctx, id, s);
    }

    private static void apply(Context ctx, int id, Snap s) {
        SharedPreferences p = prefs(ctx);
        if (s.error != ERR_NONE) { render(ctx, id, s.error == ERR_AUTH ? LOGIN : OFFLINE); return; }
        Ch c = find(s, p.getInt("w_pin_" + id, -1));
        if (c == null) { render(ctx, id, MISSING); return; }
        p.edit().putString("w_name_" + id, label(c)).putBoolean("w_on_" + id, c.on).apply();
        render(ctx, id, c.on ? ON : OFF);
    }

    /** Tap on the widget: flip the switch (force ON <-> force OFF, same as the hexagon in the app). */
    static void toggle(Context ctx, int id) {
        SharedPreferences p = prefs(ctx);
        int pin = p.getInt("w_pin_" + id, -1);
        if (pin < 0) return;
        render(ctx, id, BUSY);

        Snap s = fetch(ctx);
        if (s.error != ERR_NONE) { apply(ctx, id, s); return; }
        Ch c = find(s, pin);
        if (c == null) { render(ctx, id, MISSING); return; }

        ControllerClient.Res r = new ControllerClient(ctx)
                .req("POST", "/api/override", "ch=" + c.idx + "&mode=" + (c.on ? 2 : 1));
        if (r.status != 200) {
            toast(ctx, "Controller not responding");
        } else {
            try {
                JSONObject j = new JSONObject(r.text);
                if (!j.optBoolean("ok", false)) toast(ctx, j.optString("msg", "Not allowed"));
            } catch (Exception ignored) { }
        }
        refreshAll(ctx);
    }

    private static void toast(final Context ctx, final String msg) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show());
    }

    // ---------- drawing ----------

    /** Draw from the last known state (instant, no network). */
    static void renderCached(Context ctx, int id) {
        SharedPreferences p = prefs(ctx);
        if (p.getInt("w_pin_" + id, -1) < 0) { render(ctx, id, OFF); return; }
        render(ctx, id, p.getBoolean("w_on_" + id, false) ? ON : OFF);
    }

    static void render(Context ctx, int id, int state) {
        SharedPreferences p = prefs(ctx);
        String name = p.getString("w_name_" + id, "LIGHT");
        boolean lastOn = p.getBoolean("w_on_" + id, false);
        boolean on = state == ON || (state == BUSY && lastOn);
        boolean dim = state == BUSY || state == OFFLINE || state == LOGIN || state == MISSING;

        String sub;
        switch (state) {
            case ON:      sub = "ON"; break;
            case OFF:     sub = "OFF"; break;
            case BUSY:    sub = "…"; break;
            case LOGIN:   sub = "Log in"; break;
            case MISSING: sub = "Removed"; break;
            default:      sub = "Offline";
        }

        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_hex);
        v.setImageViewResource(R.id.wd_hex, on ? R.drawable.wd_hex_on : R.drawable.wd_hex_off);
        v.setImageViewResource(R.id.wd_ico, on ? R.drawable.wd_pwr_on : R.drawable.wd_pwr_off);
        v.setInt(R.id.wd_hex, "setImageAlpha", dim ? 120 : 255);
        v.setInt(R.id.wd_ico, "setImageAlpha", dim ? 120 : 255);
        v.setTextViewText(R.id.wd_name, name);
        v.setTextColor(R.id.wd_name, on ? 0xFFFFE9D2 : 0xFFF5F5F7);
        v.setTextViewText(R.id.wd_sub, sub);
        v.setTextColor(R.id.wd_sub, on ? 0xFFFFB347 : 0xFF8D8D97);

        PendingIntent pi;
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        if (state == LOGIN) {
            Intent open = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            if (open == null) open = new Intent();
            pi = PendingIntent.getActivity(ctx, id, open, flags);
        } else {
            Intent t = new Intent(ctx, WidgetToggleReceiver.class);
            t.setAction(ACTION_TOGGLE);
            t.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
            pi = PendingIntent.getBroadcast(ctx, id, t, flags);
        }
        v.setOnClickPendingIntent(R.id.wd_root, pi);
        AppWidgetManager.getInstance(ctx).updateAppWidget(id, v);
    }

    static void forget(Context ctx, int[] ids) {
        SharedPreferences.Editor e = prefs(ctx).edit();
        for (int id : ids) e.remove("w_pin_" + id).remove("w_name_" + id).remove("w_on_" + id);
        e.apply();
    }
}
