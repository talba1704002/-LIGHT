package com.talha.light.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Full-screen shell for the ESP32 light controller.
 * The UI (Home + Schedule) is bundled in assets/index.html. All traffic to the
 * controller goes through the Bridge below, which
 *   - always addresses the controller as http://esplight.local/ (mDNS/NSD only helps resolve that name),
 *   - keeps the login cookie of the controller,
 *   - always uses the Wi-Fi network (even when it has no internet).
 */
public class WebViewActivity extends Activity {

    private static final String UI_URL = "file:///android_asset/index.html";
    private static final long MIN_SPLASH_MS = 1200;
    private static final long WIFI_WAIT_MS = 2500;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    /** requests to the controller go one at a time: it is a tiny server and drops parallel connections */
    private final ExecutorService net = Executors.newSingleThreadExecutor();

    private FrameLayout root;
    private WebView web;
    private View splash;
    private boolean splashHidden = false;
    private long splashShownAt;

    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean started = false;
    private volatile Network boundNet = null;

    private SharedPreferences prefs;
    private int insT, insR, insB, insL;

    // ----- controller connection state -----
    private volatile String sid = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        splashShownAt = System.currentTimeMillis();
        prefs = getSharedPreferences("talha_light", MODE_PRIVATE);
        sid = prefs.getString("sid", "");

        setupEdgeToEdge();

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B0B0D);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0B0D);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);

        // system bar / cutout sizes -> CSS (so the page uses the full screen on every device)
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            insT = ins.getSystemWindowInsetTop();
            insR = ins.getSystemWindowInsetRight();
            insB = ins.getSystemWindowInsetBottom();
            insL = ins.getSystemWindowInsetLeft();
            pushInsets();
            return ins;
        });
        root.requestApplyInsets();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pushInsets();
                hideSplash();
            }
        });

        // native dialogs so alert()/confirm() in the page work
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        bindToWifiThenLoad();
    }

    // ---------- full screen (edge-to-edge) ----------

    @SuppressWarnings("deprecation")
    private void setupEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
    }

    private void pushInsets() {
        if (web == null) return;
        float d = getResources().getDisplayMetrics().density;
        final String js = "window.__insets && window.__insets("
                + (insT / d) + "," + (insR / d) + "," + (insB / d) + "," + (insL / d) + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    // ---------- networking ----------

    /** Bind this app to Wi-Fi so the controller is reachable even when Android prefers mobile data. */
    private void bindToWifiThenLoad() {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network n) {
                    boundNet = n;
                    try { cm.bindProcessToNetwork(n); } catch (Exception ignored) {}
                    resolvedIp = null; // re-resolve on the new network
                    handler.post(WebViewActivity.this::startLoad);
                }

                @Override
                public void onLost(Network n) {
                    if (boundNet != null && !boundNet.equals(n)) return;   // an old Wi-Fi went away, the new one stays bound
                    boundNet = null;
                    try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {}
                    resolvedIp = null;
                }
            };
            cm.requestNetwork(req, netCb);
        } catch (Exception e) {
            startLoad();
            return;
        }
        handler.postDelayed(this::startLoad, WIFI_WAIT_MS); // no Wi-Fi? start anyway
    }

    private void startLoad() {
        if (started) return;
        started = true;
        web.loadUrl(UI_URL);
    }

    /** Result of one HTTP call. status 0 = could not connect. */
    private static class Res {
        int status;
        String text = "";
        boolean connectFailed;
    }

    /** Every request is addressed to http://esplight.local/ - never to a typed or fixed IP.
     *  Only if Android itself cannot resolve the .local name, the name is resolved through the
     *  mDNS service search below and the connection goes to that address while the request
     *  still says "Host: esplight.local". */
    private static final String NAME = "esplight.local";
    private volatile String resolvedIp = null;

    /** mDNS / DNS-SD search for the controller's "_http._tcp" service named "esplight".
     *  This works even when Android cannot resolve "esplight.local" by name. */
    private String nsdFind(long timeoutMs) {
        final NsdManager nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
        if (nsd == null) return null;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] found = new String[1];

        final NsdManager.DiscoveryListener dl = new NsdManager.DiscoveryListener() {
            @Override public void onStartDiscoveryFailed(String t, int e) { latch.countDown(); }
            @Override public void onStopDiscoveryFailed(String t, int e) { }
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceLost(NsdServiceInfo i) { }

            @Override
            public void onServiceFound(NsdServiceInfo info) {
                String n = info.getServiceName();
                if (n == null || !n.toLowerCase().contains("esplight")) return;
                try {
                    nsd.resolveService(info, new NsdManager.ResolveListener() {
                        @Override public void onResolveFailed(NsdServiceInfo i, int e) { }

                        @Override
                        public void onServiceResolved(NsdServiceInfo i) {
                            if (i.getHost() instanceof Inet4Address) {
                                found[0] = i.getHost().getHostAddress();
                                latch.countDown();
                            }
                        }
                    });
                } catch (Exception ignored) { }
            }
        };

        try {
            nsd.discoverServices("_http._tcp.", NsdManager.PROTOCOL_DNS_SD, dl);
            latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (Exception ignored) {
        } finally {
            try { nsd.stopServiceDiscovery(dl); } catch (Exception ignored) { }
        }
        return found[0];
    }

    /** One full try: remembered address first, then the .local name, then the mDNS search. */
    private Res attempt(String method, String path, String body) {
        // Fast path: the address that worked last time (the request still says Host: esplight.local).
        // Asking Android to resolve the .local name on EVERY request is what made taps slow.
        Res r = null;
        String ip = resolvedIp;
        if (ip != null) {
            r = doRequest(ip, method, path, body);
            if ((r.status == 0 && r.connectFailed) || r.status == 404) { resolvedIp = null; r = null; }
        }
        if (r == null) {
            r = doRequest(null, method, path, body);              // http://esplight.local/...
            if (r.status == 0 && r.connectFailed) {
                String f = nsdFind(4000);
                if (f != null) {
                    resolvedIp = f;
                    r = doRequest(f, method, path, body);
                    if (r.status == 0 && r.connectFailed) resolvedIp = null;
                }
            } else if (r.status != 0) {
                resolvedIp = lookupName();                        // name works: remember its address
            }
        }
        return r;
    }

    private String lookupName() {
        try {
            java.net.InetAddress a = java.net.InetAddress.getByName(NAME);
            if (a instanceof Inet4Address) return a.getHostAddress();
        } catch (Exception ignored) { }
        return null;
    }

    private Res doRequest(String ip, String method, String path, String body) {
        Res r = new Res();
        HttpURLConnection c = null;
        boolean sent = false;
        try {
            c = (HttpURLConnection) new URL("http://" + (ip == null ? NAME : ip) + path).openConnection();
            if (ip != null) c.setRequestProperty("Host", NAME);
            c.setConnectTimeout(ip != null ? 2000 : 3500);
            c.setReadTimeout(6000);
            c.setRequestMethod(method);
            if (sid.length() > 0) c.setRequestProperty("Cookie", "sid=" + sid);
            if (!"GET".equals(method)) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                byte[] data = (body == null ? "" : body).getBytes("UTF-8");
                c.setFixedLengthStreamingMode(data.length);
                OutputStream o = c.getOutputStream();
                o.write(data);
                o.close();
            }
            sent = true;
            r.status = c.getResponseCode();

            List<String> cookies = c.getHeaderFields().get("Set-Cookie");
            if (cookies != null) {
                for (String ck : cookies) {
                    if (ck != null && ck.startsWith("sid=")) {
                        int e = ck.indexOf(';');
                        sid = ck.substring(4, e < 0 ? ck.length() : e);
                        prefs.edit().putString("sid", sid).apply();
                    }
                }
            }

            InputStream in = r.status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                r.text = bo.toString("UTF-8");
            }
        } catch (Exception e) {
            r.status = 0;
            r.connectFailed = !sent;
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    private final Runnable widgetRefresh = new Runnable() {
        @Override public void run() {
            final Context app = getApplicationContext();
            try { io.execute(() -> WidgetHelper.refreshAll(app)); } catch (Exception ignored) { }
        }
    };

    private long lastTileSync = 0;

    private class Bridge {
        /** The widget needs the password to log in again by itself (it cannot reach the WebView storage). */
        @JavascriptInterface
        public void savePassword(String pw) {
            prefs.edit().putString("pw", pw == null ? "" : pw).apply();
        }

        @JavascriptInterface
        public void clearPassword() {
            prefs.edit().remove("pw").apply();
        }

        /** Called by the page after a switch was changed, so the home-screen widgets follow. */
        @JavascriptInterface
        public void refreshWidgets() {
            final Context app = getApplicationContext();
            // wait a moment so it never competes with the app's own requests on the small controller
            handler.removeCallbacks(widgetRefresh);
            handler.postDelayed(widgetRefresh, 1500);
        }

        @JavascriptInterface
        public void request(final int id, final String method, final String path, final String body) {
            net.execute(() -> {
                Res r = attempt(method, path, body);
                // one quick retry: the request never left the phone, or it is a harmless GET
                if (r.status == 0 && (r.connectFailed || "GET".equals(method))) {
                    try { Thread.sleep(300); } catch (InterruptedException ignored) { }
                    r = attempt(method, path, body);
                }
                final String js = "window.__native(" + id + "," + r.status + "," + JSONObject.quote(r.text) + ")";
                handler.post(() -> { if (!isFinishing()) web.evaluateJavascript(js, null); });
            });
        }
    }

    // ---------- splash ----------

    private void buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(0xFF0B0B0D);
        f.setClickable(true);
        // Vector logo: scales to any screen with no blur/stretch.
        ImageView iv = new ImageView(this) {
            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                int side = Math.min(w, h);
                int padX = (w - Math.round(side * 0.40f)) / 2;
                int padY = (h - Math.round(side * 0.40f * 470f / 357f)) / 2;
                setPadding(padX, padY, padX, padY);
            }
        };
        iv.setImageResource(R.drawable.splash_logo);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        splash = f;
    }

    private void hideSplash() {
        if (splashHidden) return;
        splashHidden = true;
        long wait = MIN_SPLASH_MS - (System.currentTimeMillis() - splashShownAt);
        handler.postDelayed(() -> splash.animate().alpha(0f).setDuration(350)
                .withEndAction(() -> splash.setVisibility(View.GONE)).start(), Math.max(0, wait));
    }

    // ---------- lifecycle ----------

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back && window.__back()", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        web.evaluateJavascript("window.__resume && window.__resume()", null);
        final Context app = getApplicationContext();
        long now = System.currentTimeMillis();
        if (now - lastTileSync > 30000) {
            lastTileSync = now;
            try { io.execute(() -> TileHelper.syncFromController(app)); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onPause() {
        final Context app = getApplicationContext();
        try { io.execute(() -> { WidgetHelper.refreshAll(app); TileHelper.syncFromController(app); }); } catch (Exception ignored) {}
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        io.shutdownNow();
        net.shutdownNow();
        try { if (netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) {}
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {}
        ((ViewGroup) root).removeView(web);
        web.destroy();
        super.onDestroy();
    }
}
