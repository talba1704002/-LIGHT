Talha Light - full-screen WebView app for the ESP32 light controller

1. Create a new GitHub repo and upload EVERYTHING from this zip (keep the folder structure,
   including the hidden ".github" folder).
2. Go to the repo > Actions > "Build Android APK" (runs on every push, or press "Run workflow").
3. When it finishes, open the run and download the artifact "TalhaLight-apk" -> TalhaLight.apk
4. Install on the phone (allow "install unknown apps").

The app bundles its own interface (Home + Schedule) in app/src/main/assets/index.html and talks to the
controller (firmware v14.x, password login) through a Java bridge:
  - every request is sent to http://esplight.local/ (no IP addresses are used or typed). If Android cannot
    resolve the .local name itself, the name is resolved through an mDNS service search and the request still
    carries "Host: esplight.local".
  - keeps the login cookie and re-logs in with the saved password after a controller reboot.
  - always uses the Wi-Fi network, even if it has no internet.
Top bar: CPU temperature, RTC status (tap = set clock to phone time), settings (edit mode: rename / change
GPIO / delete switches), plus (new switch, default name = its GPIO pin). Switches are hexagons in a honeycomb.

HOME-SCREEN WIDGET (v1.1)
  Long-press the home screen > Widgets > LIGHT > drag the hexagon out. A list of the controller's
  switches appears; tap the one (GPIO) this widget should control. Add as many widgets as you like,
  one per switch. Tapping a widget toggles that switch (force ON <-> force OFF, like the hexagon in the app).
  The widget logs in by itself using the password saved by the app (open the app and log in once).
  It refreshes after each tap, when you leave the app, and every ~30 minutes. Needs the phone on the
  controller's Wi-Fi network (same as the app).
  The password is saved only for the widget. The app itself never logs in with it: if the controller
  asks for a password (e.g. after a reboot) the app shows its login page.

QUICK SETTINGS TILES (v1.2)
  Swipe down the notification shade > pencil (edit) > drag the "LIGHT" tiles into the panel.
  There is one tile per switch of the controller: the list shows exactly as many tiles as you have
  switches (the first switch is "LIGHT 1" in the list, but once placed the tile shows the switch's own name).
  Add a new switch in the app -> a new tile appears in the edit list. Delete a switch -> its tile disappears.
  Tap a tile = turn that switch ON/OFF (same as the hexagon). The tile shows ON / OFF / Offline / Log in.
  Open the app once after installing/updating (and log in) so the tiles can find your switches.
  Up to 16 switches are supported (TileHelper.SLOTS; add more SwitchTileService$SlotN + manifest entries for more).
  Each tile keeps its switch, so tiles don't shuffle when other switches are added or removed.
  Tile list changes may need the shade/edit screen to be reopened to show up.

SPEED (v1.3)
  The app now remembers the controller's address and talks to it directly (Host: esplight.local is still sent),
  instead of resolving the .local name on every request. Switch taps show the new state instantly and are
  confirmed by the controller a moment later. Widget refresh after a tap is delayed/debounced so it never
  competes with the app's own requests.

CONNECTION STABILITY (v1.4)
  - Wi-Fi roaming / reconnect no longer drops the app off the Wi-Fi network (an old network's "lost" event
    used to unbind the new one, sending requests over mobile data).
  - Requests to the controller go one at a time, status polls never overlap, and a failed request is retried once.
  - The "connection lost" screen now appears only after ~12 s of failed polls (was ~6 s).
  - When the app returns to the screen it re-checks the controller immediately.

SPEED (v1.5)
  - A failed request no longer blocks the request queue for long: connect timeout 1.5 s on the known address,
    mDNS search only every 15 s (and 2.5 s max), retry pause 150 ms (was 300 ms).
  - Use together with firmware v14.10 (Wi-Fi power-save off, CPU >= 160 MHz, AP max clients 4).

CONNECTION + SPEED FIX (v1.6)
  Cause: the app, the widget and every quick tile each talked to the controller on their own, at the same time.
  The ESP32 web server handles one client at a time, so parallel requests stalled and dropped; every widget/tile tap
  also cost 5-7 requests, and a single connect hiccup erased the saved address and triggered slow .local / mDNS lookups.
  - ONE request at a time for the whole app (app screen + widgets + tiles share one lock and one address cache).
  - The app screen now uses the same client as the widgets (the duplicate code is gone).
  - The saved address is kept on timeouts; it is only dropped after 2 real connect failures, and the slow name/mDNS
    search runs at most every 8 s (in between requests fail fast instead of blocking the queue).
  - Switch list is cached and re-read only when the controller's config version changes: a read is 1 request, not 2.
  - Widget/tile tap = 3 requests (state, flip, confirm) instead of ~7; the widget shows the new state instantly.
  - Opening the shade with several tiles shares ONE read. Leaving/returning to the app does ONE read, not 5.
  - Sockets are never kept alive (Connection: close), so no stale socket can block the controller.
  Firmware unchanged: light_controller_v14_11.ino.

FIRMWARE: light_controller_v14_11.ino (in this zip) - flash with Arduino IDE; use it together with this app (v1.5).
  Wi-Fi power-save off, CPU >= 160 MHz, AP max clients 4, router reconnect 1 s / 10 s (300 s while a phone is on the AP).
  Not compiled or hardware-tested here: keep your old firmware as a backup.
  The zip contains a signing keystore + passwords (app/build.gradle): do not publish it publicly.
