package com.talha.light.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.Looper;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/**
 * One Quick Settings tile = one switch of the controller.
 * The concrete SlotN classes below are what the manifest declares.
 */
public abstract class SwitchTileService extends TileService {

    abstract int slot();

    private final Handler ui = new Handler(Looper.getMainLooper());

    private SharedPreferences prefs() {
        return getApplicationContext().getSharedPreferences(ControllerClient.PREFS, Context.MODE_PRIVATE);
    }

    @Override
    public void onStartListening() {
        super.onStartListening();
        draw(null);                       // instant, from the last known state
        final Context app = getApplicationContext();
        new Thread(() -> {
            // all tiles opening together share ONE read of the controller (<= 2.5 s old)
            WidgetHelper.Snap s = WidgetHelper.fetchRecent(app, 2500);
            TileHelper.sync(app, s);
            ui.post(() -> draw(s));
        }).start();
    }

    @Override
    public void onClick() {
        super.onClick();
        final int slot = slot();
        final Context app = getApplicationContext();
        final int pin = prefs().getInt("t_pin_" + slot, -1);
        if (pin < 0) return;

        // show the new state at once, then confirm with the controller
        final boolean was = prefs().getBoolean("t_on_" + slot, false);
        paint(!was);

        new Thread(() -> {
            // 3 quick requests (state, flip, confirm); widgets and tiles follow from the last read
            WidgetHelper.Snap s2 = WidgetHelper.toggleByPin(app, pin);
            ui.post(() -> draw(s2));
        }).start();
    }

    @Override
    public void onTileAdded() {
        super.onTileAdded();
        draw(null);
    }

    // ---------- drawing ----------

    /** snap == null: draw from the cache; otherwise from the fresh read (error = offline / login). */
    private void draw(WidgetHelper.Snap snap) {
        Tile t = getQsTile();
        if (t == null) return;
        int slot = slot();
        SharedPreferences p = prefs();
        int pin = p.getInt("t_pin_" + slot, -1);
        String name = p.getString("t_name_" + slot, "GPIO" + pin);

        if (pin < 0) {
            t.setLabel("LIGHT");
            t.setState(Tile.STATE_UNAVAILABLE);
            setSub(t, "No switch");
            t.setIcon(Icon.createWithResource(this, R.drawable.ic_tile_power));
            t.updateTile();
            return;
        }
        t.setLabel(name);
        t.setIcon(Icon.createWithResource(this, R.drawable.ic_tile_power));

        if (snap != null && snap.error != WidgetHelper.ERR_NONE) {
            t.setState(Tile.STATE_UNAVAILABLE);
            setSub(t, snap.error == WidgetHelper.ERR_AUTH ? "Log in" : "Offline");
        } else {
            boolean on = p.getBoolean("t_on_" + slot, false);
            t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
            setSub(t, on ? "ON" : "OFF");
        }
        t.updateTile();
    }

    private void paint(boolean on) {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        setSub(t, "…");
        t.updateTile();
    }

    private static void setSub(Tile t, String s) {
        if (android.os.Build.VERSION.SDK_INT >= 29) t.setSubtitle(s);
    }

    // ---------- the slots declared in AndroidManifest.xml ----------
    public static final class Slot1 extends SwitchTileService { @Override int slot() { return 1; } }
    public static final class Slot2 extends SwitchTileService { @Override int slot() { return 2; } }
    public static final class Slot3 extends SwitchTileService { @Override int slot() { return 3; } }
    public static final class Slot4 extends SwitchTileService { @Override int slot() { return 4; } }
    public static final class Slot5 extends SwitchTileService { @Override int slot() { return 5; } }
    public static final class Slot6 extends SwitchTileService { @Override int slot() { return 6; } }
    public static final class Slot7 extends SwitchTileService { @Override int slot() { return 7; } }
    public static final class Slot8 extends SwitchTileService { @Override int slot() { return 8; } }
    public static final class Slot9 extends SwitchTileService { @Override int slot() { return 9; } }
    public static final class Slot10 extends SwitchTileService { @Override int slot() { return 10; } }
    public static final class Slot11 extends SwitchTileService { @Override int slot() { return 11; } }
    public static final class Slot12 extends SwitchTileService { @Override int slot() { return 12; } }
    public static final class Slot13 extends SwitchTileService { @Override int slot() { return 13; } }
    public static final class Slot14 extends SwitchTileService { @Override int slot() { return 14; } }
    public static final class Slot15 extends SwitchTileService { @Override int slot() { return 15; } }
    public static final class Slot16 extends SwitchTileService { @Override int slot() { return 16; } }
}
