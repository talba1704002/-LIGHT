package com.talha.light.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Small HTTP client for the ESP32 controller, used by the home-screen widget
 * (the main screen has its own copy of this logic inside WebViewActivity).
 *  - talks to http://esplight.local/ (falls back to the last known address / an mDNS search)
 *  - uses the Wi-Fi network directly, so it works from the background
 *  - shares the login cookie ("sid") with the app and logs in again with the saved password on 401
 */
final class ControllerClient {

    static final String PREFS = "talha_light";
    private static final String NAME = "esplight.local";

    static final class Res {
        int status;            // 0 = could not connect
        String text = "";
        boolean connectFailed;
    }

    private final Context app;
    private final SharedPreferences prefs;
    private static volatile long lastNsdAt = 0;   // do not repeat the slow mDNS search back-to-back
    private static volatile long lastRecoverAt = 0;
    private static volatile int ipFails = 0;
    /** ONE request at a time for the whole process (app, widgets, tiles): the ESP32 web server is single-threaded
     *  and stalls / drops connections when several clients hit it in parallel. */
    private static final ReentrantLock NET = new ReentrantLock(true);

    static {
        // every request opens and closes its own socket: no stale keep-alive socket can ever block the controller
        System.setProperty("http.keepAlive", "false");
    }

    ControllerClient(Context c) {
        app = c.getApplicationContext();
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Request with automatic re-login. body must already be form-encoded. */
    Res req(String method, String path, String body) {
        NET.lock();
        try {
            Res r = send(method, path, body);
            if (r.status == 401) {
                String pw = prefs.getString("pw", "");
                if (pw.length() > 0 && login(pw)) r = send(method, path, body);
            }
            return r;
        } finally { NET.unlock(); }
    }

    /** Same, but never logs in by itself (the app shows its own login page). */
    Res reqRaw(String method, String path, String body) {
        NET.lock();
        try { return send(method, path, body); } finally { NET.unlock(); }
    }

    boolean hasPassword() {
        return prefs.getString("pw", "").length() > 0;
    }

    private boolean login(String pw) {
        try {
            Res r = send("POST", "/api/auth/login", "pass=" + URLEncoder.encode(pw, "UTF-8"));
            return r.status == 200 && r.text.contains("\"ok\":true");
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- connection strategy: name -> last known address -> mDNS search ----------

    private Res send(String method, String path, String body) {
        Res r = send0(method, path, body);
        if (r.status == 0 && (r.connectFailed || "GET".equals(method))) {
            try { Thread.sleep(200); } catch (InterruptedException ignored) { }
            r = send0(method, path, body);
        }
        return r;
    }

    private Res send0(String method, String path, String body) {
        // fast path: the address that worked last time (Host header still says esplight.local)
        String ip = prefs.getString("ip", null);
        if (ip != null) {
            Res r = once(ip, method, path, body);
            if (!r.connectFailed && r.status != 404) { ipFails = 0; return r; }   // answered, or just slow: keep the address
            if (r.status == 404) {
                prefs.edit().remove("ip").apply();                                // another device took that address
                ipFails = 0;
            } else if (++ipFails < 2) {
                return r;                                                         // one hiccup: the caller retries the SAME address
            } else {
                prefs.edit().remove("ip").apply();
                ipFails = 0;
            }
        }
        // slow path (only after the address really failed twice): at most one search every 8 s,
        // in between requests fail fast instead of blocking everybody
        long now = System.currentTimeMillis();
        if (now - lastRecoverAt < 8000) {
            Res f = new Res();
            f.connectFailed = true;
            return f;
        }
        lastRecoverAt = now;
        Res r = once(null, method, path, body);
        if (!r.connectFailed) {
            if (r.status != 0) rememberName();
            return r;
        }
        String found = nsdFind(2500);
        lastNsdAt = System.currentTimeMillis();
        if (found != null) {
            prefs.edit().putString("ip", found).apply();
            r = once(found, method, path, body);
        }
        lastRecoverAt = System.currentTimeMillis();   // the 8 s gate starts after the search, not before it
        return r;
    }

    private void rememberName() {
        try {
            Network n = wifi();
            java.net.InetAddress a = n != null ? n.getByName(NAME) : java.net.InetAddress.getByName(NAME);
            if (a instanceof Inet4Address) prefs.edit().putString("ip", a.getHostAddress()).apply();
        } catch (Exception ignored) { }
    }

    @SuppressWarnings("deprecation")
    private Network wifi() {
        try {
            ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities c = cm.getNetworkCapabilities(n);
                if (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private Res once(String ip, String method, String path, String body) {
        Res r = new Res();
        HttpURLConnection c = null;
        boolean sent = false;
        try {
            URL url = new URL("http://" + (ip == null ? NAME : ip) + path);
            Network n = wifi();
            c = (HttpURLConnection) (n != null ? n.openConnection(url) : url.openConnection());
            if (ip != null) c.setRequestProperty("Host", NAME);
            c.setConnectTimeout(ip != null ? 2500 : 3000);
            c.setRequestProperty("Connection", "close");
            c.setReadTimeout(6000);
            c.setRequestMethod(method);
            String sid = prefs.getString("sid", "");
            if (sid.length() > 0) c.setRequestProperty("Cookie", "sid=" + sid);
            if (!"GET".equals(method)) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                byte[] data = (body == null ? "" : body).getBytes("UTF-8");
                c.setFixedLengthStreamingMode(data.length);
                OutputStream o = c.getOutputStream();
                o.write(data);
                o.close();
            }
            sent = true;
            r.status = c.getResponseCode();

            List<String> cookies = c.getHeaderFields().get("Set-Cookie");
            if (cookies != null) {
                for (String ck : cookies) {
                    if (ck != null && ck.startsWith("sid=")) {
                        int e = ck.indexOf(';');
                        prefs.edit().putString("sid", ck.substring(4, e < 0 ? ck.length() : e)).apply();
                    }
                }
            }

            InputStream in = r.status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int k;
                while ((k = in.read(buf)) > 0) bo.write(buf, 0, k);
                in.close();
                r.text = bo.toString("UTF-8");
            }
        } catch (Exception e) {
            r.status = 0;
            r.connectFailed = !sent;
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    private String nsdFind(long timeoutMs) {
        final NsdManager nsd = (NsdManager) app.getSystemService(Context.NSD_SERVICE);
        if (nsd == null) return null;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] found = new String[1];

        final NsdManager.DiscoveryListener dl = new NsdManager.DiscoveryListener() {
            @Override public void onStartDiscoveryFailed(String t, int e) { latch.countDown(); }
            @Override public void onStopDiscoveryFailed(String t, int e) { }
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceLost(NsdServiceInfo i) { }

            @Override
            public void onServiceFound(NsdServiceInfo info) {
                String n = info.getServiceName();
                if (n == null || !n.toLowerCase().contains("esplight")) return;
                try {
                    nsd.resolveService(info, new NsdManager.ResolveListener() {
                        @Override public void onResolveFailed(NsdServiceInfo i, int e) { }

                        @Override
                        public void onServiceResolved(NsdServiceInfo i) {
                            if (i.getHost() instanceof Inet4Address) {
                                found[0] = i.getHost().getHostAddress();
                                latch.countDown();
                            }
                        }
                    });
                } catch (Exception ignored) { }
            }
        };

        try {
            nsd.discoverServices("_http._tcp.", NsdManager.PROTOCOL_DNS_SD, dl);
            latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (Exception ignored) {
        } finally {
            try { nsd.stopServiceDiscovery(dl); } catch (Exception ignored) { }
        }
        return found[0];
    }
}
