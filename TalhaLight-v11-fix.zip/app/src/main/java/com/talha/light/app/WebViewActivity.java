package com.talha.light.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Full-screen shell for the ESP32 light controller.
 * The UI (Home + Schedule) is bundled in assets/index.html. All traffic to the
 * controller goes through the Bridge below, which
 *   - always addresses the controller as http://esplight.local/ (mDNS/NSD only helps resolve that name),
 *   - keeps the login cookie of the controller,
 *   - always uses the Wi-Fi network (even when it has no internet).
 */
public class WebViewActivity extends Activity {

    private static final String UI_URL = "file:///android_asset/index.html";
    private static final long MIN_SPLASH_MS = 1200;
    private static final long WIFI_WAIT_MS = 2500;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    /** requests to the controller go one at a time: it is a tiny server and drops parallel connections */
    private final ExecutorService net = Executors.newSingleThreadExecutor();

    private FrameLayout root;
    private WebView web;
    private View splash;
    private boolean splashHidden = false;
    private long splashShownAt;

    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean started = false;
    private volatile Network boundNet = null;

    private SharedPreferences prefs;
    private int insT, insR, insB, insL;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        splashShownAt = System.currentTimeMillis();
        prefs = getSharedPreferences("talha_light", MODE_PRIVATE);
        client = new ControllerClient(this);

        setupEdgeToEdge();

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B0B0D);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0B0D);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);

        // system bar / cutout sizes -> CSS (so the page uses the full screen on every device)
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            insT = ins.getSystemWindowInsetTop();
            insR = ins.getSystemWindowInsetRight();
            insB = ins.getSystemWindowInsetBottom();
            insL = ins.getSystemWindowInsetLeft();
            pushInsets();
            return ins;
        });
        root.requestApplyInsets();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pushInsets();
                hideSplash();
            }
        });

        // native dialogs so alert()/confirm() in the page work
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        bindToWifiThenLoad();
    }

    // ---------- full screen (edge-to-edge) ----------

    @SuppressWarnings("deprecation")
    private void setupEdgeToEdge() {
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
    }

    private void pushInsets() {
        if (web == null) return;
        float d = getResources().getDisplayMetrics().density;
        final String js = "window.__insets && window.__insets("
                + (insT / d) + "," + (insR / d) + "," + (insB / d) + "," + (insL / d) + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    // ---------- networking ----------

    /** Bind this app to Wi-Fi so the controller is reachable even when Android prefers mobile data. */
    private void bindToWifiThenLoad() {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network n) {
                    boundNet = n;
                    try { cm.bindProcessToNetwork(n); } catch (Exception ignored) {}
                    handler.post(WebViewActivity.this::startLoad);
                }

                @Override
                public void onLost(Network n) {
                    if (boundNet != null && !boundNet.equals(n)) return;   // an old Wi-Fi went away, the new one stays bound
                    boundNet = null;
                    try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {}
                }
            };
            cm.requestNetwork(req, netCb);
        } catch (Exception e) {
            startLoad();
            return;
        }
        handler.postDelayed(this::startLoad, WIFI_WAIT_MS); // no Wi-Fi? start anyway
    }

    private void startLoad() {
        if (started) return;
        started = true;
        web.loadUrl(UI_URL);
    }

    /** All traffic goes through ControllerClient (same code, same address cache and the same
     *  one-request-at-a-time lock as the widgets and tiles). The app never logs in by itself. */
    private ControllerClient client;

    private final Runnable widgetRefresh = new Runnable() {
        @Override public void run() {
            final Context app = getApplicationContext();
            try { io.execute(() -> WidgetHelper.refreshAll(app)); } catch (Exception ignored) { }
        }
    };

    private long lastTileSync = 0;

    private class Bridge {
        /** The widget needs the password to log in again by itself (it cannot reach the WebView storage). */
        @JavascriptInterface
        public void savePassword(String pw) {
            prefs.edit().putString("pw", pw == null ? "" : pw).apply();
        }

        @JavascriptInterface
        public void clearPassword() {
            prefs.edit().remove("pw").apply();
        }

        /** Called by the page after a switch was changed, so the home-screen widgets follow. */
        @JavascriptInterface
        public void refreshWidgets() {
            final Context app = getApplicationContext();
            // wait a moment so it never competes with the app's own requests on the small controller
            handler.removeCallbacks(widgetRefresh);
            handler.postDelayed(widgetRefresh, 1500);
        }

        @JavascriptInterface
        public void request(final int id, final String method, final String path, final String body) {
            net.execute(() -> {
                ControllerClient.Res r = client.reqRaw(method, path, body);   // retries / address recovery are inside
                final String js = "window.__native(" + id + "," + r.status + "," + JSONObject.quote(r.text) + ")";
                handler.post(() -> { if (!isFinishing()) web.evaluateJavascript(js, null); });
            });
        }
    }

    // ---------- splash ----------

    private void buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(0xFF0B0B0D);
        f.setClickable(true);
        // Vector logo: scales to any screen with no blur/stretch.
        ImageView iv = new ImageView(this) {
            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                int side = Math.min(w, h);
                int padX = (w - Math.round(side * 0.40f)) / 2;
                int padY = (h - Math.round(side * 0.40f * 470f / 357f)) / 2;
                setPadding(padX, padY, padX, padY);
            }
        };
        iv.setImageResource(R.drawable.splash_logo);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        splash = f;
    }

    private void hideSplash() {
        if (splashHidden) return;
        splashHidden = true;
        long wait = MIN_SPLASH_MS - (System.currentTimeMillis() - splashShownAt);
        handler.postDelayed(() -> splash.animate().alpha(0f).setDuration(350)
                .withEndAction(() -> splash.setVisibility(View.GONE)).start(), Math.max(0, wait));
    }

    // ---------- lifecycle ----------

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back && window.__back()", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        web.evaluateJavascript("window.__resume && window.__resume()", null);
        // tiles/widgets sync a little later and only now and then, so the app's own first poll goes first
        long now = System.currentTimeMillis();
        if (now - lastTileSync > 60000) {
            lastTileSync = now;
            handler.removeCallbacks(widgetRefresh);
            handler.postDelayed(widgetRefresh, 2500);
        }
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(widgetRefresh);
        final Context app = getApplicationContext();
        // ONE read of the controller refreshes widgets and tiles together
        try { io.execute(() -> WidgetHelper.refreshAll(app)); } catch (Exception ignored) {}
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        io.shutdownNow();
        net.shutdownNow();
        try { if (netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) {}
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {}
        ((ViewGroup) root).removeView(web);
        web.destroy();
        super.onDestroy();
    }
}
